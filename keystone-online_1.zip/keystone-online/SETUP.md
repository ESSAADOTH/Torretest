# Keystone online — setup guide

This puts your website and your manager online, sharing one database.
Guests can browse apartments and send booking requests from any device,
and you manage everything from any device after signing in.

About 20 minutes. Both services have free plans.

## What is in this folder

| File | What it is |
|---|---|
| `website/index.html` | The whole app: the public website and, at `#/admin`, your manager |
| `website/config.js` | Where you paste your two database values (step 3) |
| `schema.sql` | Creates the database tables and the security rules (step 2) |
| `source/` | The code, only needed if you want to change the app later |

## 1. Create the database

1. Go to [supabase.com](https://supabase.com), sign up and create a new project.
2. Choose a region close to you (for example Frankfurt) and a strong database password.
   Keep that password somewhere safe; Keystone itself does not need it.
3. Wait a minute or two until the project is ready.

## 2. Create the tables

1. In your Supabase project, open the **SQL Editor** and start a new query.
2. Open `schema.sql` in a text editor, copy everything, paste it, and click **Run**.
3. You should see a success message. Running it again later is harmless.

## 3. Connect the app to the database

1. In Supabase go to **Project Settings → API Keys** (or click **Connect** at the top).
2. Copy the **Project URL** and the **Publishable key** (starts with `sb_publishable_`).
3. Open `website/config.js` in a text editor and paste them between the quotes:

```js
window.KEYSTONE_CONFIG = {
  supabaseUrl: "https://abcdefghijkl.supabase.co",
  supabaseKey: "sb_publishable_xxxxxxxxxxxxxxxx",
};
```

Never paste the **secret** key (`sb_secret_…`) or the old `service_role` key here.
Those bypass all security rules.

## 4. Create your owner login

1. In Supabase open **Authentication → Users** and add a user with your e-mail and a password.
   Tick the option to auto-confirm the user if it is offered.
2. Back in the **SQL Editor**, run this with your own e-mail:

```sql
insert into owners (email) values ('you@example.com');
```

3. In the Authentication settings, turn **off** "Allow new users to sign up".
   Only accounts in the `owners` table can see or change data anyway,
   but there is no reason to let strangers create accounts.

To give a second person access later, create their user the same way and add
their e-mail to `owners`.

## 5. Put the website online

1. Go to [app.netlify.com/drop](https://app.netlify.com/drop) and sign up or log in.
2. Drag the **`website` folder** onto the page.
3. Netlify gives you an address such as `https://something.netlify.app`.
   You can rename it, or connect your own domain, in the site settings.

- Your public website: `https://something.netlify.app`
- Your manager: `https://something.netlify.app/#/admin` (also linked as "Owner area" in the footer)

## 6. First use

1. Open `/#/admin`, sign in, and add your apartments in **Units**.
2. Fill in **Website** (brand name, tagline, city, contact details).
3. Open the public address on your phone and send yourself a test request.
   It should appear in **Requests** on your computer.

## Updating the app later

1. If the new version comes with a new `schema.sql`, run it once in the Supabase **SQL Editor**
   (same as step 2). It only adds what is missing and never deletes your data.
2. Replace `index.html` in your `website` folder (keep your `config.js`) and drag the folder
   onto your site's **Deploys** page in Netlify.

**Upgrading from the first version:** do both steps above. The text you had written in an
apartment's notes becomes its public description (it was already shown on the website), and
the notes field is now private.

## Good to know

- **Who sees what.** Visitors can see each apartment's description, details, amenities, photos,
  prices (including seasonal prices) and which dates are taken. They cannot see bookings,
  guest names, contacts, requests or an apartment's **private notes**.
- **Pricing.** Short stays use the nightly price. Stays of 7+ nights use the weekly price and
  28+ nights the monthly price, spread per night. Nights inside a season always use the season
  price. The cleaning fee is added once. A new booking is priced automatically; you can still
  type a different price.
- **Photos** are links to images stored elsewhere (a shared album, Dropbox, your own website).
  Make sure the link opens the image itself, not a page around it.
- **Double bookings.** The database refuses a website request whose dates overlap an existing booking.
  Leaving and arriving on the same day is allowed.
- **Data from the offline version** is not copied over automatically. Re-enter your units and bookings,
  or ask for an import tool.
- **Free plan limits.** Supabase pauses free projects after about a week with no activity.
  Unpause it from the Supabase dashboard if the site stops loading, or upgrade to keep it always on.
- **Backups.** The free Supabase plan has limited backups. For important data, consider a paid plan
  or a regular export from the Table Editor.
- **No payments.** Guests send requests only. Payment and the contract are handled by you.

## If something goes wrong

| What you see | Likely cause |
|---|---|
| The site works but data does not save between devices | `config.js` still has the placeholder text, so the app runs in offline mode |
| "Wrong email or password" | Typo, or the user was not confirmed in step 4 |
| "This account is not on the owner list" | The `insert into owners` line was not run, or the e-mail differs |
| Red banner "Could not save to the database" | No connection, or the Supabase project is paused |
| The site does not load at all | Supabase project paused, or `config.js` was not uploaded with `index.html` |
| A photo does not appear | The link points to a web page, not to the image file itself |
| New fields (bedrooms, seasons…) do not save online | The new `schema.sql` was not run yet |
