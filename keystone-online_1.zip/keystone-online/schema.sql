-- =====================================================================
-- Keystone — database setup for Supabase
-- Run this whole file ONCE: Supabase dashboard -> SQL Editor -> New query
-- -> paste everything -> Run.  It is safe to run again later.
-- =====================================================================

create extension if not exists pgcrypto;

-- ------------------------------------------------------------- tables

create table if not exists units (
  id            uuid primary key default gen_random_uuid(),
  name          text not null,
  address       text default '',
  notes         text default '',          -- private: only the owner can read it
  weekly_price  numeric,
  monthly_price numeric,
  photo         text default '',
  created_at    timestamptz not null default now()
);

create table if not exists bookings (
  id             uuid primary key default gen_random_uuid(),
  unit_id        uuid not null references units(id) on delete cascade,
  guest_name     text not null default '',
  guest_contact  text default '',
  check_in       date not null,
  check_in_time  text default '15:00',
  check_out      date not null,
  check_out_time text default '11:00',
  price          numeric,
  notes          text default '',
  checked_in_at  timestamptz,
  checked_out_at timestamptz,
  created_at     timestamptz not null default now(),
  constraint bookings_dates_ok check (check_out >= check_in)
);
create index if not exists bookings_unit_dates on bookings (unit_id, check_in, check_out);

create table if not exists requests (
  id            uuid primary key default gen_random_uuid(),
  unit_id       uuid not null references units(id) on delete cascade,
  guest_name    text not null,
  guest_contact text not null,
  check_in      date not null,
  check_out     date not null,
  message       text default '',
  status        text not null default 'pending' check (status in ('pending','accepted','declined')),
  created_at    timestamptz not null default now()
);

create table if not exists site_settings (
  id      int primary key default 1 check (id = 1),
  brand   text default 'Keystone Stays',
  tagline text default 'Holiday apartments, made easy.',
  city    text default '',
  email   text default '',
  phone   text default ''
);
insert into site_settings (id) values (1) on conflict do nothing;

create table if not exists owner_info (
  id      int primary key default 1 check (id = 1),
  name    text default '',
  address text default '',
  contact text default ''
);
insert into owner_info (id) values (1) on conflict do nothing;

-- --------------------------------------- apartment details & pricing
-- (added in version 2; safe on new and existing databases)

do $$
begin
  -- Version 1 showed "notes" publicly. When the public "description" column is
  -- first created, move that text there so the website keeps showing it, and
  -- "notes" becomes private. This only happens once.
  if not exists (select 1 from information_schema.columns
                 where table_schema = 'public' and table_name = 'units' and column_name = 'description') then
    alter table units add column description text default '';
    update units set description = coalesce(notes, ''), notes = '';
  end if;
end $$;

alter table units add column if not exists bedrooms      int;
alter table units add column if not exists bathrooms     int;
alter table units add column if not exists max_guests    int;
alter table units add column if not exists amenities     jsonb not null default '[]'::jsonb;
alter table units add column if not exists photos        jsonb not null default '[]'::jsonb;
alter table units add column if not exists nightly_price numeric;
alter table units add column if not exists cleaning_fee  numeric;
alter table units add column if not exists seasons       jsonb not null default '[]'::jsonb;
update units set photos = jsonb_build_array(photo)
  where coalesce(photo, '') <> '' and photos = '[]'::jsonb;

alter table site_settings add column if not exists currency text default '€';

-- Who is allowed into the owner area. Add your login e-mail here (step 4 of SETUP).
create table if not exists owners (
  email text primary key
);

-- ------------------------------------------------------ who is owner?

create or replace function is_owner()
returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from owners o
    where lower(o.email) = lower(coalesce(auth.jwt() ->> 'email', ''))
  )
$$;

-- ---------------------------------------------------- access control

alter table units         enable row level security;
alter table bookings      enable row level security;
alter table requests      enable row level security;
alter table site_settings enable row level security;
alter table owner_info    enable row level security;
alter table owners        enable row level security;   -- no policies: nobody reads it through the API

drop policy if exists owner_all_units    on units;
drop policy if exists owner_all_bookings on bookings;
drop policy if exists owner_all_requests on requests;
drop policy if exists owner_all_site     on site_settings;
drop policy if exists owner_all_owner    on owner_info;
drop policy if exists public_read_units  on units;
drop policy if exists public_read_site   on site_settings;

-- The owner can do everything.
create policy owner_all_units    on units         for all to authenticated using (is_owner()) with check (is_owner());
create policy owner_all_bookings on bookings      for all to authenticated using (is_owner()) with check (is_owner());
create policy owner_all_requests on requests      for all to authenticated using (is_owner()) with check (is_owner());
create policy owner_all_site     on site_settings for all to authenticated using (is_owner()) with check (is_owner());
create policy owner_all_owner    on owner_info    for all to authenticated using (is_owner()) with check (is_owner());

-- Visitors may only READ the apartments and the website settings.
-- They can never read bookings, requests, guest names, contacts or private notes.
create policy public_read_units on units         for select to anon using (true);
create policy public_read_site  on site_settings for select to anon, authenticated using (true);

grant usage on schema public to anon, authenticated;
-- Visitors may read every apartment column EXCEPT the private notes.
revoke select on units from anon;
grant select (id, name, address, description, bedrooms, bathrooms, max_guests, amenities, photos, photo,
              nightly_price, weekly_price, monthly_price, cleaning_fee, seasons, created_at) on units to anon;
grant select on site_settings to anon;
grant select, insert, update, delete on units, bookings, requests, site_settings, owner_info to authenticated;

-- --------------------------------------- guest-safe website functions

-- Which dates are taken? Returns dates only, never guest details.
create or replace function get_availability()
returns table (unit_id uuid, check_in date, check_out date)
language sql stable security definer set search_path = public as $$
  select b.unit_id, b.check_in, b.check_out
  from bookings b
  where b.checked_out_at is null and b.check_out >= current_date
$$;

-- Send a booking request. Everything is checked on the server,
-- so the website cannot be used to double-book an apartment.
create or replace function submit_request(
  p_unit_id uuid, p_name text, p_contact text,
  p_check_in date, p_check_out date, p_message text
) returns uuid
language plpgsql security definer set search_path = public as $$
declare new_id uuid;
begin
  if coalesce(trim(p_name), '') = '' or coalesce(trim(p_contact), '') = '' then
    raise exception 'missing_contact';
  end if;
  if p_check_in is null or p_check_out is null
     or p_check_out <= p_check_in or p_check_in < current_date then
    raise exception 'invalid_dates';
  end if;
  if length(p_name) > 200 or length(p_contact) > 200 or length(coalesce(p_message, '')) > 2000 then
    raise exception 'too_long';
  end if;
  if not exists (select 1 from units where id = p_unit_id) then
    raise exception 'unknown_unit';
  end if;
  if exists (
    select 1 from bookings b
    where b.unit_id = p_unit_id and b.checked_out_at is null
      and b.check_in < p_check_out and b.check_out > p_check_in
  ) then
    raise exception 'unavailable';
  end if;
  insert into requests (unit_id, guest_name, guest_contact, check_in, check_out, message)
  values (p_unit_id, trim(p_name), trim(p_contact), p_check_in, p_check_out, coalesce(p_message, ''))
  returning id into new_id;
  return new_id;
end $$;

revoke all on function is_owner() from public;
revoke all on function get_availability() from public;
revoke all on function submit_request(uuid, text, text, date, date, text) from public;
grant execute on function is_owner() to anon, authenticated;
grant execute on function get_availability() to anon, authenticated;
grant execute on function submit_request(uuid, text, text, date, date, text) to anon, authenticated;
