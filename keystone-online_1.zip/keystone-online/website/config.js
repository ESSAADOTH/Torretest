// Keystone — connection settings.
// Paste your two Supabase values between the quotes (see SETUP.md, step 3).
// Both values are safe to put on a public website: the database rules
// (schema.sql) decide what visitors and the owner can see and change.
window.KEYSTONE_CONFIG = {
  supabaseUrl: "YOUR-PROJECT-URL",       // looks like https://abcdefghijkl.supabase.co
  supabaseKey: "YOUR-PUBLISHABLE-KEY",   // starts with sb_publishable_  (an older "anon" key also works)
};
