// Test double for @supabase/supabase-js: in-memory tables with the same
// visitor / owner rules as schema.sql. Used only by the automated test.
const db = (globalThis.__fakeDb = globalThis.__fakeDb || {
  units: [], bookings: [], requests: [],
  site_settings: [{ id: 1, brand: "Keystone Stays", tagline: "Holiday apartments, made easy.", city: "", email: "", phone: "", currency: "€" }],
  owner_info: [{ id: 1, name: "", address: "", contact: "" }],
  owners: ["owner@example.com"],
  users: { "owner@example.com": "pw-owner", "stranger@example.com": "pw-stranger" },
  calls: [],
});

const PUBLIC_READ = ["units", "site_settings"];
const today = () => new Date().toISOString().slice(0, 10);
const uuid = () => globalThis.crypto.randomUUID();

export function createClient() {
  let session = null;
  const listeners = [];
  const isOwner = () => !!session && db.owners.includes(session.user.email);
  const err = (m) => ({ data: null, error: { message: m } });

  function from(table) {
    const rows = () => db[table];
    const canRead = () => isOwner() || PUBLIC_READ.includes(table);
    return {
      select(cols = "*") {
        let filter = () => true;
        const pick = (r) => {
          if (cols === "*") return { ...r };
          const o = {};
          cols.split(",").forEach((c) => { o[c.trim()] = r[c.trim()]; });
          return o;
        };
        const columnDenied = () => !isOwner() && table === "units" && (cols === "*" || /(^|,)\s*notes\s*(,|$)/.test(cols));
        const q = {
          order(col, { ascending }) {
            const run = () => {
              if (!canRead() || columnDenied()) return err("permission denied for table " + table);
              const out = rows().filter(filter).map(pick);
              out.sort((a, b) => (a[col] < b[col] ? -1 : a[col] > b[col] ? 1 : 0) * (ascending ? 1 : -1));
              return { data: out, error: null };
            };
            return Promise.resolve(run());
          },
          eq(col, val) {
            filter = (r) => r[col] === val;
            return q;
          },
          maybeSingle() {
            if (!canRead()) return Promise.resolve(err("permission denied"));
            const r = rows().find(filter);
            return Promise.resolve({ data: r ? { ...r } : null, error: null });
          },
        };
        return q;
      },
      upsert(list) {
        db.calls.push({ op: "upsert", table, n: [].concat(list).length });
        if (!isOwner()) return Promise.resolve(err("new row violates row-level security policy"));
        for (const row of [].concat(list)) {
          if (table === "bookings" && row.check_out < row.check_in) return Promise.resolve(err("bookings_dates_ok"));
          const i = rows().findIndex((r) => r.id === row.id);
          const base = { created_at: new Date().toISOString() };
          if (i >= 0) rows()[i] = { ...rows()[i], ...row };
          else rows().push({ ...base, ...row, id: row.id || uuid() });
        }
        return Promise.resolve({ data: null, error: null });
      },
      delete() {
        return {
          in(col, ids) {
            db.calls.push({ op: "delete", table, n: ids.length });
            if (!isOwner()) return Promise.resolve({ data: null, error: null }); // RLS: silently no rows
            db[table] = rows().filter((r) => !ids.includes(r[col]));
            if (table === "units") {
              db.bookings = db.bookings.filter((b) => !ids.includes(b.unit_id));
              db.requests = db.requests.filter((b) => !ids.includes(b.unit_id));
            }
            return Promise.resolve({ data: null, error: null });
          },
        };
      },
    };
  }

  function rpc(name, p) {
    db.calls.push({ op: "rpc", name });
    if (name === "is_owner") return Promise.resolve({ data: isOwner(), error: null });
    if (name === "get_availability") {
      return Promise.resolve({
        data: db.bookings.filter((b) => !b.checked_out_at && b.check_out >= today()).map((b) => ({ unit_id: b.unit_id, check_in: b.check_in, check_out: b.check_out })),
        error: null,
      });
    }
    if (name === "submit_request") {
      if (!p.p_name?.trim() || !p.p_contact?.trim()) return Promise.resolve(err("missing_contact"));
      if (!p.p_check_in || !p.p_check_out || p.p_check_out <= p.p_check_in || p.p_check_in < today()) return Promise.resolve(err("invalid_dates"));
      if (!db.units.some((u) => u.id === p.p_unit_id)) return Promise.resolve(err("unknown_unit"));
      if (db.bookings.some((b) => b.unit_id === p.p_unit_id && !b.checked_out_at && b.check_in < p.p_check_out && b.check_out > p.p_check_in))
        return Promise.resolve(err("unavailable"));
      const id = uuid();
      db.requests.push({ id, unit_id: p.p_unit_id, guest_name: p.p_name.trim(), guest_contact: p.p_contact.trim(), check_in: p.p_check_in, check_out: p.p_check_out, message: p.p_message || "", status: "pending", created_at: new Date().toISOString() });
      return Promise.resolve({ data: id, error: null });
    }
    return Promise.resolve(err("unknown rpc"));
  }

  const auth = {
    getSession: () => Promise.resolve({ data: { session } }),
    onAuthStateChange(cb) {
      listeners.push(cb);
      return { data: { subscription: { unsubscribe() { listeners.splice(listeners.indexOf(cb), 1); } } } };
    },
    signInWithPassword({ email, password }) {
      if (db.users[email] !== password) return Promise.resolve({ data: null, error: { message: "Invalid login credentials" } });
      session = { user: { id: "u-" + email, email } };
      listeners.forEach((l) => l("SIGNED_IN", session));
      return Promise.resolve({ data: { session }, error: null });
    },
    signOut() {
      session = null;
      listeners.forEach((l) => l("SIGNED_OUT", null));
      return Promise.resolve({ error: null });
    },
  };

  return { from, rpc, auth };
}
