import fs from "fs";
import { DEFAULT_CONTRACT, setLanguage, setCurrency } from "../src/app.jsx";
import { buildContractPdf } from "../src/pdf.js";
const out = process.argv[2];
const unit = { name: "Sea View", address: "12 Rue de la Plage, Nice", nightlyPrice: "120", cleaningFee: "60",
  seasons: [{ id: "s", name: "Été", start: "2026-07-01", end: "2026-08-31", nightlyPrice: "180", yearly: true }] };
const booking = { guestName: "Marie Dupont", guestContact: "marie@example.com", checkIn: "2027-06-28", checkInTime: "15:00",
  checkOut: "2027-07-03", checkOutTime: "11:00", price: "780" };
const owner = { name: "Casa Azul SARL", address: "4 Avenue Jean Médecin, 06000 Nice", contact: "+33 6 12 34 56 78 · hello@casa-azul.fr" };
setCurrency("€");
for (const lang of ["en", "fr"]) {
  setLanguage(lang);
  const text = DEFAULT_CONTRACT({ owner, unit, booking });
  fs.writeFileSync(`${out}/contract-${lang}.txt`, text);
  const doc = buildContractPdf(text, { brand: owner.name, reference: "Sea View · 28 Jun – 3 Jul 2027", dateLabel: lang === "fr" ? "Date :" : "Date:" });
  fs.writeFileSync(`${out}/contract-${lang}.pdf`, Buffer.from(doc.output("arraybuffer")));
}
// a long edited contract must flow onto a second page
setLanguage("en");
const long = DEFAULT_CONTRACT({ owner, unit, booking }).replace("Signed,", Array.from({ length: 30 }, (_, i) => `${i + 6}. Extra clause added by the owner to check that long contracts continue on a new page without losing text.`).join("\n") + "\n\nSigned,");
fs.writeFileSync(`${out}/contract-long.pdf`, Buffer.from(buildContractPdf(long, { brand: "Casa Azul" }).output("arraybuffer")));
console.log("pdfs written");
