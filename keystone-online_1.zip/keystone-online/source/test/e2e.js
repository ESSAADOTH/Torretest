// End-to-end test: owner sign-in, managing units/bookings, website requests.
const { JSDOM, VirtualConsole } = require("jsdom");
const fs = require("fs");
const path = require("path");
const { webcrypto } = require("crypto");

const file = process.argv[2];
const online = process.argv[3] !== "local";
const html = fs.readFileSync(file, "utf8");
const addDays = (n) => { const d = new Date(); d.setDate(d.getDate() + n); return d.toISOString().slice(0, 10); };
const wait = (ms) => new Promise((r) => setTimeout(r, ms));

const errors = [];
const vc = new VirtualConsole();
// Ignore features the test browser (jsdom) does not implement but real browsers do:
// scrolling, navigation, and jsPDF's canvas feature check on page load.
vc.on("jsdomError", (e) => { if (!/scrollTo|navigation|HTMLCanvasElement's getContext/.test(e.message)) errors.push((e.detail?.stack || e.message).slice(0, 400)); });
vc.on("error", (...a) => errors.push("console.error: " + a.map(String).join(" ").slice(0, 400)));

const dom = new JSDOM(html, {
  runScripts: "dangerously", url: "https://keystone.example/#/", pretendToBeVisual: true, virtualConsole: vc,
  beforeParse(w) {
    Object.defineProperty(w, "crypto", { value: webcrypto });
    w.URL.createObjectURL = () => "blob:keystone-test";
    w.URL.revokeObjectURL = () => {};
    w.open = (u) => { w.__opened = u; return null; };
    if (online) w.KEYSTONE_CONFIG = { supabaseUrl: "https://abc.supabase.co", supabaseKey: "sb_publishable_test" };
  },
});
const w = dom.window, d = w.document;
const text = () => d.getElementById("root").textContent;
const results = [];
const check = (name, ok, extra = "") => { results.push(ok); console.log((ok ? "PASS " : "FAIL ") + name + (extra ? "  (" + extra + ")" : "")); };

const nativeSet = (el, v) => {
  const proto = el.tagName === "TEXTAREA" ? w.HTMLTextAreaElement.prototype : el.tagName === "SELECT" ? w.HTMLSelectElement.prototype : w.HTMLInputElement.prototype;
  Object.getOwnPropertyDescriptor(proto, "value").set.call(el, v);
  el.dispatchEvent(new w.Event(el.tagName === "SELECT" ? "change" : "input", { bubbles: true }));
};
const field = (label) => {
  const l = [...d.querySelectorAll("label")].find((x) => x.textContent.trim() === label);
  if (!l) throw new Error("no field " + label);
  return l.parentElement.querySelector("input,textarea,select");
};
const click = (txt, nth = 0) => {
  const bs = [...d.querySelectorAll("button")].filter((x) => x.textContent.trim().startsWith(txt));
  if (!bs[nth]) throw new Error("no button " + txt);
  bs[nth].dispatchEvent(new w.MouseEvent("click", { bubbles: true }));
};
const clickTitle = (title) => {
  const b = d.querySelector(`button[title="${title}"]`);
  if (!b) throw new Error("no button titled " + title);
  b.dispatchEvent(new w.MouseEvent("click", { bubbles: true }));
};
const go = async (hash) => { w.location.hash = hash; await wait(250); };
const login = async (email, pw) => {
  nativeSet(field("Email"), email); nativeSet(field("Password"), pw);
  d.querySelector("form").dispatchEvent(new w.Event("submit", { bubbles: true, cancelable: true }));
  await wait(300);
};
const fake = () => w.__fakeDb;

(async () => {
  await wait(400);
  check("landing renders with no apartments", text().includes("No apartments are listed yet."));

  await go("#/admin");
  if (online) {
    check("owner area asks for sign-in", text().includes("Owner sign-in"));
    await login("owner@example.com", "wrong");
    check("wrong password rejected", text().includes("Wrong email or password."));
    await login("stranger@example.com", "pw-stranger");
    check("non-owner account is blocked", text().includes("not on the owner list"));
    click("Sign out"); await wait(200);
    await login("owner@example.com", "pw-owner");
  }
  check("owner reaches dashboard", text().includes("Overview"));

  // add unit
  click("Units"); await wait(100);
  click("Add unit"); await wait(100);
  nativeSet(field("Unit name"), "Sea View");
  nativeSet(field("Bedrooms"), "2"); nativeSet(field("Max guests"), "4");
  nativeSet(field("Description (shown on the website)"), "Balcony over the bay");
  nativeSet(field("Nightly price"), "100"); nativeSet(field("Weekly price"), "560"); nativeSet(field("Cleaning fee"), "50");
  nativeSet(field("Private notes (only you see these)"), "Key box code 4471");
  nativeSet(d.querySelector('input[aria-label="Photo URL"]'), "https://example.com/sea-view.jpg");
  click("Wi-Fi"); click("Kitchen"); await wait(50);
  click("Add seasonal price"); await wait(50);
  nativeSet(d.querySelector('input[aria-label="Season name (e.g. Summer)"]'), "Festival");
  await wait(30);
  click("Save unit"); await wait(100);
  check("half-filled season blocks saving", text().includes("Complete or remove the unfinished seasonal price."));
  nativeSet(field("From"), addDays(8)); nativeSet(field("To"), addDays(9)); nativeSet(field("Price per night"), "150");
  const sp = [...d.querySelectorAll('input[type="checkbox"]')].find((c) => c.parentElement.textContent.includes("Repeats every year"));
  sp.dispatchEvent(new w.MouseEvent("click", { bubbles: true }));
  await wait(80);
  check("example price shown while editing", text().includes("Example: 7 nights from today would cost"));
  click("Save unit"); await wait(250);
  if (online) {
    const u = fake().units[0] || {};
    check("unit details saved to database",
      u.nightly_price === 100 && u.weekly_price === 560 && u.cleaning_fee === 50 && u.bedrooms === 2 && u.max_guests === 4 &&
      JSON.stringify(u.amenities) === '["wifi","kitchen"]' && u.photos.length === 1 && u.seasons.length === 1 && u.seasons[0].yearly === false &&
      u.description === "Balcony over the bay" && u.notes === "Key box code 4471",
      JSON.stringify(u).slice(0, 160));
  }
  check("unit card shows details", text().includes("2 bedrooms") && text().includes("€100") && text().includes("1 seasonal price") && text().includes("Key box code 4471"));
  click("Add unit"); await wait(100);
  nativeSet(field("Unit name"), "Old Town"); await wait(50);
  click("Save unit"); await wait(250);

  // add booking on Sea View
  click("Bookings"); await wait(100);
  click("New booking"); await wait(100);
  nativeSet(field("Guest name"), "Secret Guest"); nativeSet(field("Guest phone / email"), "secret@x.com");
  nativeSet(field("Check-in date"), addDays(5)); nativeSet(field("Check-out date"), addDays(12));
  await wait(100);
  // 7 nights: 5 regular nights at the weekly rate (560/7 = 80) + 2 festival nights at 150 + 50 cleaning = 750
  check("suggested price calculated", text().includes("Suggested price") && field("Price (total)").value === "750", "price=" + field("Price (total)").value);
  click("Save booking"); await wait(250);
  if (online) check("booking saved with price", fake().bookings.length === 1 && fake().bookings[0].guest_name === "Secret Guest" && fake().bookings[0].price === 750);

  // website settings
  click("Website"); await wait(100);
  nativeSet(field("Brand name"), "Casa Azul"); await wait(250);
  if (online) check("website brand saved", fake().site_settings[0].brand === "Casa Azul");

  // calendar
  click("Calendar"); await wait(150);
  let found = !!d.querySelector('[title*="Secret Guest"]');
  if (!found) {
    const nav = [...d.querySelectorAll("button")].filter((b) => b.querySelector("svg") && !b.textContent.trim());
    nav[nav.length - 1].dispatchEvent(new w.MouseEvent("click", { bubbles: true }));
    await wait(150);
    found = !!d.querySelector('[title*="Secret Guest"]');
  }
  check("calendar renders the booking", found);

  // visitor flow
  if (online) { click("Sign out"); await wait(200); }
  await go("#/");
  check("landing shows brand and units", text().includes("Casa Azul") && text().includes("Sea View") && text().includes("Old Town"));
  check("landing shows apartment details", text().includes("Balcony over the bay") && text().includes("Wi-Fi") && text().includes("4 guests") && text().includes("€100") && !!d.querySelector('img[src="https://example.com/sea-view.jpg"]'));
  check("private notes not on website", !text().includes("Key box code"));
  if (online) check("visitor never receives guest names", !text().includes("Secret Guest") && !JSON.stringify(w.localStorage).includes("Secret"));
  const dates = () => [...d.querySelectorAll('input[type="date"]')];
  nativeSet(dates()[0], addDays(6)); await wait(50);
  nativeSet(dates()[1], addDays(9)); await wait(150);
  check("booked apartment shown as unavailable", text().includes("Not available for these dates") && text().includes("1 apartment available"));
  nativeSet(dates()[0], addDays(12)); await wait(50);
  nativeSet(dates()[1], addDays(14)); await wait(150);
  check("same-day turnover is bookable", text().includes("2 apartments available"));
  check("total shown for chosen dates", text().includes("€250"), "2 nights x 100 + 50 cleaning");
  click("Request to book"); await wait(150);
  check("request form shows estimate", text().includes("Estimated total"));
  nativeSet(field("Your name"), "Marie Dupont"); nativeSet(field("Email or phone"), "marie@example.com"); await wait(50);
  click("Send request"); await wait(300);
  check("visitor request sent", text().includes("Request sent!"));
  if (online) check("request stored in database", fake().requests.length === 1 && fake().requests[0].status === "pending");
  click("Close"); await wait(100);

  // owner accepts
  await go("#/admin");
  if (online) await login("owner@example.com", "pw-owner");
  click("Requests"); await wait(200);
  check("owner sees the request", text().includes("Marie Dupont"));
  click("Accept"); await wait(300);
  if (online) check("accept creates priced booking + marks request", fake().bookings.length === 2 && fake().requests[0].status === "accepted" && fake().bookings[1].price === 250, JSON.stringify(fake().bookings.map((b) => b.price)));

  // contract PDF
  click("Contracts"); await wait(120);
  const sel = d.querySelector("select");
  const opt = [...sel.options].find((o) => o.textContent.includes("Secret Guest"));
  nativeSet(sel, opt.value); await wait(150);
  const contract = d.querySelector("textarea").value;
  check("contract includes price breakdown", contract.includes("Total price: €750") && contract.includes("Cleaning fee: €50") && contract.includes("Festival"));
  click("Download PDF"); await wait(200);
  click("Open & print"); await wait(200);
  check("PDF opens for printing", w.__opened === "blob:keystone-test");

  // delete a booking
  click("Bookings"); await wait(150);
  clickTitle("Delete"); await wait(100);
  click("Delete", [...d.querySelectorAll("button")].filter((x) => x.textContent.trim().startsWith("Delete")).length - 1); await wait(300);
  if (online) check("delete removes booking from database", fake().bookings.length === 1);

  // French
  click("FR"); await wait(150);
  check("French switch works in manager", text().includes("Réservations"));

  check("no runtime errors", errors.length === 0, errors.slice(0, 3).join(" | "));
  const failed = results.filter((x) => !x).length;
  console.log(`\n${results.length - failed}/${results.length} passed`);
  process.exit(failed ? 1 : 0);
})().catch((e) => { console.log("CRASH", e.message, "\n", errors.slice(0, 3).join("\n")); process.exit(1); });
