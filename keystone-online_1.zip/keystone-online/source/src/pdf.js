// Turns the (editable) contract text into a formatted A4 PDF.
// Layout rules, based on the text itself so manual edits are kept:
//   first non-empty line            -> centered title
//   short line ending with ":"      -> section heading
//   line starting with "1." etc.    -> numbered clause with hanging indent
//   line of underscores             -> two signature lines, next line = their labels
import { jsPDF } from "jspdf";

const INK = [32, 48, 47];
const SOFT = [92, 107, 106];
const ACCENT = [51, 89, 90];
const RULE = [226, 223, 211];

// Standard PDF fonts only cover Western European characters (WinAnsi).
function clean(s) {
  return String(s)
    .replace(/[    ]/g, " ")
    .replace(/[‘’]/g, "'")
    .replace(/[“”]/g, '"')
    .replace(/→/g, "->")
    .replace(/[^\x00-\xFF€–—…•ŒœŠšŸŽžƒˆ˜†‡‰‹›™]/g, "?");
}

export function buildContractPdf(text, opts = {}) {
  const doc = new jsPDF({ unit: "pt", format: "a4" });
  const W = doc.internal.pageSize.getWidth();
  const H = doc.internal.pageSize.getHeight();
  const M = 60;
  const width = W - M * 2;
  let y = 0;

  const header = () => {
    doc.setFont("helvetica", "bold");
    doc.setFontSize(9);
    doc.setTextColor(...ACCENT);
    doc.text(clean(opts.brand || ""), M, 40);
    if (opts.reference) {
      doc.setFont("helvetica", "normal");
      doc.setTextColor(...SOFT);
      doc.text(clean(opts.reference), W - M, 40, { align: "right" });
    }
    doc.setDrawColor(...RULE);
    doc.setLineWidth(0.8);
    doc.line(M, 48, W - M, 48);
    y = 78;
  };
  const ensure = (h) => {
    if (y + h > H - 60) {
      doc.addPage();
      header();
    }
  };
  header();

  const lines = clean(text).replace(/\r/g, "").split("\n");
  let titleDone = false;

  for (let i = 0; i < lines.length; i++) {
    const raw = lines[i];
    const line = raw.trim();

    if (!line) {
      y += 7;
      continue;
    }

    if (!titleDone) {
      titleDone = true;
      doc.setFont("helvetica", "bold");
      doc.setFontSize(16);
      doc.setTextColor(...INK);
      const wrapped = doc.splitTextToSize(line, width);
      ensure(wrapped.length * 20 + 14);
      wrapped.forEach((w) => {
        doc.text(w, W / 2, y, { align: "center" });
        y += 20;
      });
      y += 10;
      continue;
    }

    // signature block: a line made of underscores (one or more groups)
    if (/^_{5,}/.test(line)) {
      ensure(80);
      y += 34;
      const colW = (width - 40) / 2;
      doc.setDrawColor(...INK);
      doc.setLineWidth(0.7);
      doc.line(M, y, M + colW, y);
      doc.line(M + colW + 40, y, W - M, y);
      const next = (lines[i + 1] || "").trim();
      const labels = next ? next.split(/\s{2,}/).filter(Boolean) : [];
      if (labels.length) i += 1;
      doc.setFont("helvetica", "normal");
      doc.setFontSize(9.5);
      doc.setTextColor(...SOFT);
      if (labels[0]) doc.text(labels[0], M, y + 14);
      if (labels[1]) doc.text(labels[1], M + colW + 40, y + 14);
      doc.text(clean(opts.dateLabel || "Date:") + " ____________", M, y + 30);
      doc.text(clean(opts.dateLabel || "Date:") + " ____________", M + colW + 40, y + 30);
      y += 44;
      continue;
    }

    const isHeading = /:\s*$/.test(line) && line.length <= 60 && !/^\d+\./.test(line);
    if (isHeading) {
      ensure(34);
      y += 8;
      doc.setFont("helvetica", "bold");
      doc.setFontSize(10.5);
      doc.setTextColor(...ACCENT);
      doc.text(line.replace(/\s*:\s*$/, "").toUpperCase(), M, y);
      y += 16;
      continue;
    }

    const numbered = line.match(/^(\d+\.)\s+(.*)$/);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(10);
    doc.setTextColor(...INK);
    if (numbered) {
      const indent = 18;
      const wrapped = doc.splitTextToSize(numbered[2], width - indent);
      ensure(wrapped.length * 14 + 4);
      doc.setFont("helvetica", "bold");
      doc.text(numbered[1], M, y);
      doc.setFont("helvetica", "normal");
      wrapped.forEach((w) => {
        doc.text(w, M + indent, y);
        y += 14;
      });
      y += 3;
    } else {
      const wrapped = doc.splitTextToSize(line, width);
      ensure(wrapped.length * 14);
      wrapped.forEach((w) => {
        doc.text(w, M, y);
        y += 14;
      });
    }
  }

  const pages = doc.getNumberOfPages();
  for (let p = 1; p <= pages; p++) {
    doc.setPage(p);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8.5);
    doc.setTextColor(...SOFT);
    doc.text(`${p} / ${pages}`, W - M, H - 32, { align: "right" });
  }
  return doc;
}
