import React, { useState, useEffect, useMemo, useCallback } from "react";
import {
  LayoutDashboard,
  Building2,
  CalendarDays,
  ClipboardList,
  FileText,
  Plus,
  X,
  Pencil,
  Trash2,
  LogIn,
  LogOut,
  ChevronLeft,
  ChevronRight,
  Download,
  Printer,
  AlertTriangle,
  Check,
  Inbox,
  Globe,
  ExternalLink,
  BedDouble,
  Bath,
  Users,
  Lock,
  FileDown,
} from "lucide-react";
import { buildContractPdf } from "./pdf.js";

/* ---------------------------------------------------------------
   Keystone — a single-owner, multi-unit rental management console
   Data is stored per-user via window.storage (personal, not shared)
----------------------------------------------------------------*/

const LANG_KEY = "keystone:lang";
let CURRENT_LANG = "en";
const FR = {"Overview": "Aperçu", "Units": "Logements", "Calendar": "Calendrier", "Bookings": "Réservations", "Contracts": "Contrats", "unit managed": "logement géré", "units managed": "logements gérés", "New booking": "Nouvelle réservation", "In house": "Sur place", "Arriving today": "Arrivées aujourd'hui", "Departing today": "Départs aujourd'hui", "Needs attention": "À traiter", "Next 7 days": "7 prochains jours", "No arrivals in the next week.": "Aucune arrivée dans les 7 prochains jours.", "Upcoming": "À venir", "Arrives today": "Arrive aujourd'hui", "Departs today": "Part aujourd'hui", "Completed": "Terminé", "Unnamed guest": "Client sans nom", "Unnamed": "Sans nom", "Unknown unit": "Logement inconnu", "unit": "logement", "Check in": "Arrivée", "Check out": "Départ", "Undo check-out": "Annuler le départ", "Add unit": "Ajouter un logement", "No units yet. Add your first apartment to get started.": "Aucun logement pour l'instant. Ajoutez votre premier appartement pour commencer.", "Occupied": "Occupé", "Vacant": "Libre", "per week": "par semaine", "per month": "par mois", "Edit": "Modifier", "Delete": "Supprimer", "property": "propriété", "properties": "propriétés", "Occupancy across all units": "Occupation de tous les logements", "Today": "Aujourd'hui", "Add a unit to see it on the calendar.": "Ajoutez un logement pour le voir dans le calendrier.", "Unit": "Logement", "total": "au total", "Add a unit first, then create a booking.": "Ajoutez d'abord un logement, puis créez une réservation.", "No bookings yet.": "Aucune réservation pour l'instant.", "nights": "nuits", "night": "nuit", "Generate a rental agreement from a booking": "Générez un contrat de location à partir d'une réservation", "Manager / company name": "Nom du gestionnaire / société", "Manager address": "Adresse du gestionnaire", "Manager phone / email": "Téléphone / e-mail du gestionnaire", "Booking": "Réservation", "Select a booking…": "Sélectionner une réservation…", "Download .txt": "Télécharger .txt", "Print": "Imprimer", "Edit unit": "Modifier le logement", "Unit name": "Nom du logement", "Address": "Adresse", "Weekly price": "Prix par semaine", "Monthly price": "Prix par mois", "Notes": "Notes", "Save unit": "Enregistrer le logement", "Cancel": "Annuler", "Edit booking": "Modifier la réservation", "Guest name": "Nom du client", "Guest phone / email": "Téléphone / e-mail du client", "Check-in date": "Date d'arrivée", "Check-in time": "Heure d'arrivée", "Check-out date": "Date de départ", "Check-out time": "Heure de départ", "Price (total)": "Prix (total)", "Check-out must be on or after check-in.": "Le départ doit avoir lieu le jour de l'arrivée ou après.", "Save booking": "Enregistrer la réservation", "Confirm delete": "Confirmer la suppression", "? This can't be undone.": " ? Cette action est irréversible.", "Loading…": "Chargement…", "SHORT-TERM RENTAL AGREEMENT": "CONTRAT DE LOCATION DE COURTE DURÉE", "Between (the \"Manager\"):": "Entre (le « Gestionnaire ») :", "And (the \"Guest\"):": "Et (le « Client ») :", "[Manager / Company Name]": "[Nom du gestionnaire / société]", "[Manager Address]": "[Adresse du gestionnaire]", "[Manager Phone / Email]": "[Téléphone / e-mail du gestionnaire]", "[Guest Name]": "[Nom du client]", "[Guest Phone / Email]": "[Téléphone / e-mail du client]", "Property:": "Logement :", "Term:": "Durée :", "Check-in:": "Arrivée :", "Check-out:": "Départ :", " at ": " à ", "Rate:": "Tarif :", "[Rate not set]": "[Tarif non défini]", "Terms:": "Conditions :", "1. The Guest agrees to occupy the property only for the dates stated above and to vacate by the checkout time on the final day.": "1. Le Client s'engage à occuper le logement uniquement aux dates indiquées ci-dessus et à le libérer à l'heure de départ le dernier jour.", "2. The Guest is responsible for any damage to the property beyond normal wear and tear during the stay.": "2. Le Client est responsable de tout dommage causé au logement pendant le séjour, au-delà de l'usure normale.", "3. No smoking and no unregistered guests beyond those disclosed to the Manager.": "3. Il est interdit de fumer et d'héberger des personnes non déclarées au Gestionnaire.", "4. Cancellations and refunds are governed by the policy communicated at the time of booking.": "4. Les annulations et remboursements sont régis par la politique communiquée lors de la réservation.", "5. The Manager may enter the property with reasonable notice for maintenance or emergencies.": "5. Le Gestionnaire peut entrer dans le logement moyennant un préavis raisonnable pour l'entretien ou en cas d'urgence.", "Signed,": "Signé,", "Manager": "Gestionnaire", "Guest": "Client"};
function t(str) {
  return CURRENT_LANG === "fr" && FR[str] ? FR[str] : str;
}
const LOC = () => (CURRENT_LANG === "fr" ? "fr-FR" : "en-US");
Object.assign(FR, {
  "Requests": "Demandes", "Website": "Site web", "Arrival": "Arrivée", "Departure": "Départ",
  "Find your stay": "Trouvez votre séjour", "Our apartments": "Nos appartements",
  "Request to book": "Demander à réserver", "Not available for these dates": "Indisponible pour ces dates",
  "How it works": "Comment ça marche", "Pick your dates": "Choisissez vos dates",
  "Choose an apartment and the dates that suit you.": "Choisissez un appartement et les dates qui vous conviennent.",
  "Send a request": "Envoyez une demande", "Tell us who you are. No payment needed yet.": "Dites-nous qui vous êtes. Aucun paiement n'est demandé pour l'instant.",
  "Get a confirmation": "Recevez une confirmation", "We confirm availability and send your rental agreement.": "Nous confirmons la disponibilité et vous envoyons votre contrat de location.",
  "Contact": "Contact", "Owner area": "Espace propriétaire", "Your name": "Votre nom", "Email or phone": "E-mail ou téléphone",
  "Message (optional)": "Message (facultatif)", "Send request": "Envoyer la demande",
  "Request sent! We will get back to you shortly.": "Demande envoyée ! Nous vous répondons très vite.", "Close": "Fermer",
  "Please choose valid dates.": "Veuillez choisir des dates valides.", "Sorry, those dates are no longer available.": "Désolé, ces dates ne sont plus disponibles.",
  "Please enter your name and contact.": "Merci d'indiquer votre nom et un moyen de vous contacter.", "Something went wrong. Please try again.": "Une erreur est survenue. Veuillez réessayer.",
  "No apartments are listed yet.": "Aucun appartement n'est encore proposé.", "Clear dates": "Effacer les dates",
  "apartment available": "appartement disponible", "apartments available": "appartements disponibles",
  "Pending": "En attente", "Handled": "Traitées", "Accept": "Accepter", "Decline": "Refuser", "Accepted": "Acceptée", "Declined": "Refusée",
  "No requests yet. Requests from your website will appear here.": "Aucune demande pour l'instant. Les demandes de votre site apparaîtront ici.",
  "Dates overlap an existing booking": "Ces dates chevauchent une réservation existante",
  "Booking requests from your website": "Demandes de réservation reçues via votre site",
  "Description (shown on the website)": "Description (affichée sur le site)",
  "Private notes (only you see these)": "Notes privées (visibles par vous seul)",
  "Details": "Détails",
  "Photos": "Photos",
  "Amenities": "Équipements",
  "Pricing": "Tarifs",
  "Seasonal prices": "Tarifs saisonniers",
  "Private": "Privé",
  "Bedrooms": "Chambres",
  "Bathrooms": "Salles de bain",
  "Max guests": "Voyageurs max.",
  "bedroom": "chambre",
  "bedrooms": "chambres",
  "bathroom": "salle de bain",
  "bathrooms": "salles de bain",
  "guest": "voyageur",
  "guests": "voyageurs",
  "Photo URL": "URL de la photo",
  "Add photo": "Ajouter une photo",
  "Remove": "Retirer",
  "Cover": "Couverture",
  "Make cover": "Mettre en couverture",
  "Paste a link to an image (for example from Google Photos shared albums, Dropbox or your website). The first photo is the cover.": "Collez le lien d'une image (par exemple d'un album partagé, de Dropbox ou de votre site). La première photo sert de couverture.",
  "Nightly price": "Prix par nuit",
  "Cleaning fee": "Frais de ménage",
  "Short stays use the nightly price. Stays of 7+ nights use the weekly price, 28+ nights the monthly price. Season nights always use the season price.": "Les courts séjours utilisent le prix par nuit. Dès 7 nuits, le prix à la semaine s'applique, dès 28 nuits le prix au mois. Les nuits en saison utilisent toujours le prix de la saison.",
  "Season name (e.g. Summer)": "Nom de la saison (ex. Été)",
  "From": "Du",
  "To": "Au",
  "Price per night": "Prix par nuit",
  "Repeats every year": "Se répète chaque année",
  "Add seasonal price": "Ajouter un tarif saisonnier",
  "Complete or remove the unfinished seasonal price.": "Complétez ou retirez le tarif saisonnier incomplet.",
  "Example: 7 nights from today would cost": "Exemple : 7 nuits à partir d'aujourd'hui coûteraient",
  "Add a price to see an example.": "Ajoutez un prix pour voir un exemple.",
  "Season": "Saison",
  "Nightly rate": "Tarif à la nuit",
  "Weekly rate": "Tarif à la semaine",
  "Monthly rate": "Tarif au mois",
  "Suggested price": "Prix suggéré",
  "Use this price": "Utiliser ce prix",
  "Total": "Total",
  "No price set for this apartment yet.": "Aucun prix défini pour ce logement.",
  "seasonal price": "tarif saisonnier",
  "seasonal prices": "tarifs saisonniers",
  "per night": "par nuit",
  "from": "à partir de",
  "night": "nuit",
  "Currency": "Devise",
  "Price:": "Prix :",
  "Total price": "Prix total",
  "Download PDF": "Télécharger le PDF",
  "Open & print": "Ouvrir et imprimer",
  "Date:": "Date :",
  "Wi-Fi": "Wi-Fi",
  "Kitchen": "Cuisine",
  "Washing machine": "Lave-linge",
  "Air conditioning": "Climatisation",
  "Heating": "Chauffage",
  "Parking": "Parking",
  "Balcony / terrace": "Balcon / terrasse",
  "Elevator": "Ascenseur",
  "TV": "Télévision",
  "Workspace": "Espace de travail",
  "Pool": "Piscine",
  "Sea view": "Vue sur la mer",
  "Pets allowed": "Animaux acceptés",
  "Baby crib": "Lit bébé",
  "Dishwasher": "Lave-vaisselle",
  "more": "de plus",
  "Estimated total": "Total estimé",
  "Previous photo": "Photo précédente",
  "Next photo": "Photo suivante",
  "Owner sign-in": "Connexion propriétaire", "Email": "E-mail", "Password": "Mot de passe", "Sign in": "Se connecter",
  "Sign out": "Se déconnecter",
  "This account is not on the owner list. Add its e-mail to the owners table in Supabase (see SETUP), then sign in again.": "Ce compte n'est pas dans la liste des propriétaires. Ajoutez son e-mail à la table owners dans Supabase (voir SETUP), puis reconnectez-vous.", "Wrong email or password.": "E-mail ou mot de passe incorrect.", "Back to website": "Retour au site",
  "Could not save to the database. Check your connection, then reload the page.": "Impossible d'enregistrer dans la base de données. Vérifiez votre connexion puis rechargez la page.",
  "Branding and contact details shown to visitors": "Image de marque et coordonnées affichées aux visiteurs",
  "Brand name": "Nom de la marque", "Tagline": "Slogan", "City / area": "Ville / quartier", "Contact email": "E-mail de contact",
  "Contact phone": "Téléphone de contact", "Open website": "Ouvrir le site", "Photo URL (shown on the website)": "URL de la photo (affichée sur le site)",
  "Your website lives at the address of this file followed by #/ and the owner area at #/admin. Booking requests sent from the website arrive in Requests.": "Votre site se trouve à l'adresse de ce fichier suivie de #/ et l'espace propriétaire à #/admin. Les demandes envoyées depuis le site arrivent dans Demandes.",
});

async function readKey(key, fallback, raw) {
  try {
    const r = await window.storage.get(key, false);
    if (!r) return fallback;
    return raw ? r.value : JSON.parse(r.value);
  } catch (e) {
    return fallback;
  }
}

function isAvailable(unitId, ci, co, bookings) {
  if (!ci || !co || co <= ci) return true;
  return !bookings.some(
    (b) => b.unitId === unitId && !b.checkedOutAt && b.checkIn && b.checkOut && b.checkIn < co && b.checkOut > ci
  );
}

const REQ_KEY = "keystone:requests";
const SITE_KEY = "keystone:site";
const DEFAULT_SITE = { brand: "Keystone Stays", tagline: "Holiday apartments, made easy.", city: "", email: "", phone: "", currency: "€" };

const UNITS_KEY = "keystone:units";
const BOOKINGS_KEY = "keystone:bookings";
const OWNER_KEY = "keystone:owner-info";

const FONT_STYLE = `
  @import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600&family=Inter:wght@400;500;600;700&display=swap');
  .kf-serif { font-family: 'Fraunces', Georgia, serif; }
  .kf-sans { font-family: 'Inter', system-ui, sans-serif; }
`;

const COLORS = {
  bg: "#F6F5F0",
  surface: "#FFFFFF",
  ink: "#20302F",
  inkSoft: "#5C6B6A",
  border: "#E2DFD3",
  accent: "#33595A",
  accentSoft: "#DCE7E6",
  amber: "#B8763E",
  amberSoft: "#F3E3D2",
  green: "#4C7A5E",
  greenSoft: "#DCE9E0",
  red: "#B24B3E",
  redSoft: "#F4DEDA",
};

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

function parseDate(str) {
  return new Date(str + "T00:00:00");
}

function fmtDate(str, opts) {
  if (!str) return "—";
  return parseDate(str).toLocaleDateString(
    LOC(),
    opts || { month: "short", day: "numeric", year: "numeric" }
  );
}

function fmtTime(str) {
  if (!str) return "";
  const [h, m] = str.split(":").map(Number);
  const d = new Date();
  d.setHours(h, m);
  return d.toLocaleTimeString(LOC(), { hour: "numeric", minute: "2-digit" });
}

function nights(checkIn, checkOut) {
  if (!checkIn || !checkOut) return 0;
  const ms = parseDate(checkOut) - parseDate(checkIn);
  return Math.max(0, Math.round(ms / 86400000));
}

/* ---------------- money & pricing ---------------- */

let CURRENCY = "€";
const CURRENCIES = ["€", "$", "£", "CHF", "MAD"];

export function numOrNull(v) {
  if (v === "" || v == null) return null;
  const n = Number(v);
  return isNaN(n) ? null : n;
}
function round2(n) {
  return Math.round(n * 100) / 100;
}
export function money(v) {
  const n = numOrNull(v);
  if (n == null) return "";
  const s = n.toLocaleString(LOC(), { minimumFractionDigits: Number.isInteger(n) ? 0 : 2, maximumFractionDigits: 2 });
  if (CURRENCY === "€") return CURRENT_LANG === "fr" ? s + " €" : "€" + s;
  if (CURRENCY.length > 1) return s + " " + CURRENCY;
  return CURRENCY + s;
}
export function setLanguage(l) {
  CURRENT_LANG = l === "fr" ? "fr" : "en";
}
export function setCurrency(c) {
  CURRENCY = c || "€";
}
function addDaysStr(str, n) {
  const d = new Date(str + "T00:00:00Z");
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}

const AMENITIES = [
  ["wifi", "Wi-Fi"], ["kitchen", "Kitchen"], ["washer", "Washing machine"], ["dishwasher", "Dishwasher"],
  ["ac", "Air conditioning"], ["heating", "Heating"], ["parking", "Parking"], ["balcony", "Balcony / terrace"],
  ["elevator", "Elevator"], ["tv", "TV"], ["workspace", "Workspace"], ["pool", "Pool"], ["sea", "Sea view"],
  ["pets", "Pets allowed"], ["crib", "Baby crib"],
];
const AMENITY_LABEL = Object.fromEntries(AMENITIES);

// Older units kept public text in "notes" and a single "photo".
export function normUnit(u) {
  const legacy = u.description === undefined;
  return {
    ...u,
    description: legacy ? u.notes || "" : u.description || "",
    notes: legacy ? "" : u.notes || "",
    photos: Array.isArray(u.photos) ? u.photos.filter(Boolean) : u.photo ? [u.photo] : [],
    amenities: Array.isArray(u.amenities) ? u.amenities : [],
    seasons: Array.isArray(u.seasons) ? u.seasons : [],
  };
}

function seasonFor(unit, day) {
  for (const s of unit.seasons || []) {
    if (!s.start || !s.end || numOrNull(s.nightlyPrice) == null) continue;
    if (s.yearly === false) {
      if (day >= s.start && day <= s.end) return s;
    } else {
      const md = day.slice(5);
      const a = s.start.slice(5);
      const b = s.end.slice(5);
      if (a <= b ? md >= a && md <= b : md >= a || md <= b) return s;
    }
  }
  return null;
}

// Price of a stay, night by night. Returns null when no price applies.
export function quoteStay(unit, ci, co) {
  const n = nights(ci, co);
  if (!unit || !ci || !co || !n) return null;
  const nightly = numOrNull(unit.nightlyPrice);
  const weekly = numOrNull(unit.weeklyPrice);
  const monthly = numOrNull(unit.monthlyPrice);
  let base = null;
  let baseLabel = "";
  if (n >= 28 && monthly != null) { base = monthly / 30; baseLabel = "Monthly rate"; }
  else if (n >= 7 && weekly != null) { base = weekly / 7; baseLabel = "Weekly rate"; }
  else if (nightly != null) { base = nightly; baseLabel = "Nightly rate"; }
  else if (weekly != null) { base = weekly / 7; baseLabel = "Weekly rate"; }
  else if (monthly != null) { base = monthly / 30; baseLabel = "Monthly rate"; }
  const groups = new Map();
  for (let i = 0; i < n; i++) {
    const day = addDaysStr(ci, i);
    const s = seasonFor(unit, day);
    const rate = s ? numOrNull(s.nightlyPrice) : base;
    if (rate == null) return null;
    const key = s ? "s:" + (s.id || s.name) : "base";
    const g = groups.get(key) || { label: s ? s.name || t("Season") : t(baseLabel), nights: 0, rate, amount: 0 };
    g.nights += 1;
    g.amount += rate;
    groups.set(key, g);
  }
  const lines = [...groups.values()].map((g) => ({ ...g, rate: round2(g.rate), amount: round2(g.amount) }));
  const lodging = round2(lines.reduce((a, l) => a + l.amount, 0));
  const cleaning = numOrNull(unit.cleaningFee) || 0;
  return { nights: n, lines, lodging, cleaning, total: round2(lodging + cleaning) };
}

function QuoteBox({ quote, title, action }) {
  if (!quote) return null;
  return (
    <div className="rounded p-3 text-xs" style={{ background: COLORS.accentSoft, color: COLORS.ink }}>
      <div className="flex items-center justify-between gap-2 mb-1.5">
        <span className="font-semibold" style={{ color: COLORS.accent }}>{title}</span>
        {action}
      </div>
      {quote.lines.map((l, i) => (
        <div key={i} className="flex justify-between gap-3">
          <span>{l.nights} {t(l.nights === 1 ? "night" : "nights")} × {money(l.rate)} <span style={{ color: COLORS.inkSoft }}>({l.label})</span></span>
          <span>{money(l.amount)}</span>
        </div>
      ))}
      {quote.cleaning > 0 && (
        <div className="flex justify-between gap-3">
          <span>{t("Cleaning fee")}</span>
          <span>{money(quote.cleaning)}</span>
        </div>
      )}
      <div className="flex justify-between gap-3 mt-1.5 pt-1.5 font-semibold" style={{ borderTop: `1px solid rgba(51,89,90,0.25)` }}>
        <span>{t("Total")}</span>
        <span>{money(quote.total)}</span>
      </div>
    </div>
  );
}

function UnitFacts({ u, size = 12 }) {
  const items = [];
  const b = numOrNull(u.bedrooms), ba = numOrNull(u.bathrooms), g = numOrNull(u.maxGuests);
  if (b != null) items.push([BedDouble, `${b} ${t(b === 1 ? "bedroom" : "bedrooms")}`]);
  if (ba != null) items.push([Bath, `${ba} ${t(ba === 1 ? "bathroom" : "bathrooms")}`]);
  if (g != null) items.push([Users, `${g} ${t(g === 1 ? "guest" : "guests")}`]);
  if (!items.length) return null;
  return (
    <div className="flex flex-wrap gap-x-3 gap-y-1">
      {items.map(([Icon, label], i) => (
        <span key={i} className="inline-flex items-center gap-1" style={{ color: COLORS.inkSoft, fontSize: size }}>
          <Icon size={size + 1} /> {label}
        </span>
      ))}
    </div>
  );
}

function uid() {
  try {
    if (window.crypto && window.crypto.randomUUID) return window.crypto.randomUUID();
  } catch (e) {}
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    return (c === "x" ? r : (r & 0x3) | 0x8).toString(16);
  });
}

function getBookingStatus(b) {
  const t = todayStr();
  if (b.checkedOutAt) return "completed";
  if (b.checkedInAt) {
    if (b.checkOut === t) return "departure-today";
    if (b.checkOut < t) return "overdue";
    return "in-house";
  }
  if (b.checkOut < t) return "overdue";
  if (b.checkIn === t) return "arrival-today";
  if (b.checkIn > t) return "upcoming";
  return "in-house";
}

const STATUS_META = {
  upcoming: { label: "Upcoming", color: COLORS.inkSoft, bg: "#EDECE6" },
  "arrival-today": { label: "Arrives today", color: COLORS.amber, bg: COLORS.amberSoft },
  "in-house": { label: "In house", color: COLORS.accent, bg: COLORS.accentSoft },
  "departure-today": { label: "Departs today", color: COLORS.amber, bg: COLORS.amberSoft },
  overdue: { label: "Needs attention", color: COLORS.red, bg: COLORS.redSoft },
  completed: { label: "Completed", color: COLORS.green, bg: COLORS.greenSoft },
};

function priceBlock(unit, booking) {
  const sep = CURRENT_LANG === "fr" ? " : " : ": ";
  const price = numOrNull(booking.price);
  if (price == null) return t("[Rate not set]");
  const q = quoteStay(unit, booking.checkIn, booking.checkOut);
  if (!q || q.total !== price) return `${t("Total price")}${sep}${money(price)}`;
  const rows = q.lines.map((l) => `${l.nights} ${t(l.nights === 1 ? "night" : "nights")} × ${money(l.rate)} (${l.label}) = ${money(l.amount)}`);
  if (q.cleaning > 0) rows.push(`${t("Cleaning fee")}${sep}${money(q.cleaning)}`);
  rows.push(`${t("Total price")}${sep}${money(price)}`);
  return rows.join("\n");
}

export const DEFAULT_CONTRACT = ({ owner, unit, booking }) => {
  const n = nights(booking.checkIn, booking.checkOut);
  return `${t("SHORT-TERM RENTAL AGREEMENT")}

${t('Between (the "Manager"):')}
${owner.name || t("[Manager / Company Name]")}
${owner.address || t("[Manager Address]")}
${owner.contact || t("[Manager Phone / Email]")}

${t('And (the "Guest"):')}
${booking.guestName || t("[Guest Name]")}
${booking.guestContact || t("[Guest Phone / Email]")}

${t("Property:")}
${unit.name}${unit.address ? " — " + unit.address : ""}

${t("Term:")}
${t("Check-in:")} ${fmtDate(booking.checkIn)}${booking.checkInTime ? t(" at ") + fmtTime(booking.checkInTime) : ""}
${t("Check-out:")} ${fmtDate(booking.checkOut)}${booking.checkOutTime ? t(" at ") + fmtTime(booking.checkOutTime) : ""}
(${n} ${t(n === 1 ? "night" : "nights")})

${t("Price:")}
${priceBlock(unit, booking)}

${t("Terms:")}
${t("1. The Guest agrees to occupy the property only for the dates stated above and to vacate by the checkout time on the final day.")}
${t("2. The Guest is responsible for any damage to the property beyond normal wear and tear during the stay.")}
${t("3. No smoking and no unregistered guests beyond those disclosed to the Manager.")}
${t("4. Cancellations and refunds are governed by the policy communicated at the time of booking.")}
${t("5. The Manager may enter the property with reasonable notice for maintenance or emergencies.")}

${t("Signed,")}

_____________________________          _____________________________
${t("Manager")}                                  ${t("Guest")}
`;
};

export default function App() {
  const [units, setUnits] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [owner, setOwner] = useState({ name: "", address: "", contact: "" });
  const [requests, setRequests] = useState([]);
  const [site, setSite] = useState(DEFAULT_SITE);
  const [loaded, setLoaded] = useState(false);
  const [view, setView] = useState("dashboard");
  const [lang, setLang] = useState("en");
  CURRENT_LANG = lang;
  setCurrency(site.currency);

  const [unitModal, setUnitModal] = useState(null); // null | {} | unit
  const [bookingModal, setBookingModal] = useState(null);
  const [confirmDelete, setConfirmDelete] = useState(null); // {type, id, label}

  const [calMonth, setCalMonth] = useState(() => {
    const d = new Date();
    return new Date(d.getFullYear(), d.getMonth(), 1);
  });

  const [contractBookingId, setContractBookingId] = useState("");
  const [contractText, setContractText] = useState("");

  // ---- load ----
  useEffect(() => {
    (async () => {
      try {
        const u = await window.storage.get(UNITS_KEY, false);
        setUnits(u ? JSON.parse(u.value).map(normUnit) : []);
      } catch (e) {
        setUnits([]);
      }
      try {
        const b = await window.storage.get(BOOKINGS_KEY, false);
        setBookings(b ? JSON.parse(b.value) : []);
      } catch (e) {
        setBookings([]);
      }
      try {
        const o = await window.storage.get(OWNER_KEY, false);
        setOwner(o ? JSON.parse(o.value) : { name: "", address: "", contact: "" });
      } catch (e) {
        setOwner({ name: "", address: "", contact: "" });
      }
      setRequests(await readKey(REQ_KEY, []));
      setSite({ ...DEFAULT_SITE, ...(await readKey(SITE_KEY, {})) });
      try {
        const l = await window.storage.get(LANG_KEY, false);
        if (l && (l.value === "fr" || l.value === "en")) setLang(l.value);
      } catch (e) {}
      setLoaded(true);
    })();
  }, []);

  const persistUnits = useCallback(async (next) => {
    setUnits(next);
    try {
      await window.storage.set(UNITS_KEY, JSON.stringify(next), false);
    } catch (e) {
      console.error("Failed to save units", e);
    }
  }, []);

  const persistBookings = useCallback(async (next) => {
    setBookings(next);
    try {
      await window.storage.set(BOOKINGS_KEY, JSON.stringify(next), false);
    } catch (e) {
      console.error("Failed to save bookings", e);
    }
  }, []);

  const persistOwner = useCallback(async (next) => {
    setOwner(next);
    try {
      await window.storage.set(OWNER_KEY, JSON.stringify(next), false);
    } catch (e) {
      console.error("Failed to save owner info", e);
    }
  }, []);

  function changeLang(l) {
    setLang(l);
    try {
      Promise.resolve(window.storage.set(LANG_KEY, l, false)).catch(() => {});
    } catch (e) {}
  }

  async function persistRequests(next) {
    setRequests(next);
    try { await window.storage.set(REQ_KEY, JSON.stringify(next), false); } catch (e) {}
  }
  async function persistSite(next) {
    setSite(next);
    try { await window.storage.set(SITE_KEY, JSON.stringify(next), false); } catch (e) {}
  }
  function acceptRequest(r) {
    persistBookings([
      ...bookings,
      {
        id: uid(), unitId: r.unitId, guestName: r.guestName, guestContact: r.guestContact,
        checkIn: r.checkIn, checkInTime: "15:00", checkOut: r.checkOut, checkOutTime: "11:00",
        price: (() => { const q = quoteStay(unitById[r.unitId], r.checkIn, r.checkOut); return q ? String(q.total) : ""; })(),
        notes: r.message || "",
      },
    ]);
    persistRequests(requests.map((x) => (x.id === r.id ? { ...x, status: "accepted" } : x)));
  }
  function declineRequest(r) {
    persistRequests(requests.map((x) => (x.id === r.id ? { ...x, status: "declined" } : x)));
  }

  const unitById = useMemo(() => {
    const m = {};
    units.forEach((u) => (m[u.id] = u));
    return m;
  }, [units]);

  const sortedBookings = useMemo(
    () => [...bookings].sort((a, b) => (a.checkIn < b.checkIn ? -1 : 1)),
    [bookings]
  );

  const todayArrivals = sortedBookings.filter((b) => getBookingStatus(b) === "arrival-today");
  const todayDepartures = sortedBookings.filter((b) => getBookingStatus(b) === "departure-today");
  const overdue = sortedBookings.filter((b) => getBookingStatus(b) === "overdue");
  const inHouse = sortedBookings.filter((b) => getBookingStatus(b) === "in-house");
  const upcoming7 = sortedBookings.filter((b) => {
    const s = getBookingStatus(b);
    if (s !== "upcoming") return false;
    const days = (parseDate(b.checkIn) - parseDate(todayStr())) / 86400000;
    return days >= 0 && days <= 7;
  });

  function saveUnit(unit) {
    if (unit.id) {
      persistUnits(units.map((u) => (u.id === unit.id ? unit : u)));
    } else {
      persistUnits([...units, { ...unit, id: uid() }]);
    }
    setUnitModal(null);
  }

  function deleteUnit(id) {
    persistUnits(units.filter((u) => u.id !== id));
    persistBookings(bookings.filter((b) => b.unitId !== id));
    setConfirmDelete(null);
  }

  function saveBooking(b) {
    if (b.id) {
      persistBookings(bookings.map((x) => (x.id === b.id ? b : x)));
    } else {
      persistBookings([...bookings, { ...b, id: uid() }]);
    }
    setBookingModal(null);
  }

  function deleteBooking(id) {
    persistBookings(bookings.filter((b) => b.id !== id));
    setConfirmDelete(null);
  }

  function toggleCheckIn(b) {
    persistBookings(
      bookings.map((x) =>
        x.id === b.id ? { ...x, checkedInAt: x.checkedInAt ? null : new Date().toISOString() } : x
      )
    );
  }

  function toggleCheckOut(b) {
    persistBookings(
      bookings.map((x) =>
        x.id === b.id ? { ...x, checkedOutAt: x.checkedOutAt ? null : new Date().toISOString() } : x
      )
    );
  }

  useEffect(() => {
    if (!contractBookingId) {
      setContractText("");
      return;
    }
    const b = bookings.find((x) => x.id === contractBookingId);
    if (!b) return;
    const u = unitById[b.unitId] || { name: "Unknown unit" };
    setContractText(DEFAULT_CONTRACT({ owner, unit: u, booking: b }));
  }, [contractBookingId, lang, site.currency]); // eslint-disable-line

  function contractPdf() {
    const b = bookings.find((x) => x.id === contractBookingId);
    const u = b ? unitById[b.unitId] : null;
    return buildContractPdf(contractText, {
      brand: owner.name || site.brand,
      reference: b ? `${u ? u.name + " · " : ""}${fmtDate(b.checkIn)} – ${fmtDate(b.checkOut)}` : "",
      dateLabel: t("Date:"),
    });
  }
  function downloadContract() {
    const b = bookings.find((x) => x.id === contractBookingId);
    const guest = b ? (b.guestName || "guest").replace(/[^a-z0-9]+/gi, "-") : "contract";
    contractPdf().save(`contract-${guest || "guest"}.pdf`);
  }
  function openContract() {
    const url = contractPdf().output("bloburl");
    window.open(url, "_blank");
  }

  if (!loaded) {
    return (
      <div style={{ background: COLORS.bg, minHeight: "100%" }} className="kf-sans flex items-center justify-center p-12">
        <style>{FONT_STYLE}</style>
        <p style={{ color: COLORS.inkSoft }}>{t("Loading…")}</p>
      </div>
    );
  }

  return (
    <div style={{ background: COLORS.bg, color: COLORS.ink, minHeight: "100%" }} className="kf-sans">
      <style>{FONT_STYLE}</style>
      <div className="flex flex-col md:flex-row min-h-screen">
        <Sidebar view={view} setView={setView} unitCount={units.length} lang={lang} setLang={changeLang} pending={requests.filter((r) => r.status === "pending").length} />
        <main className="flex-1 p-5 md:p-8 max-w-6xl">
          {view === "dashboard" && (
            <Dashboard
              units={units}
              todayArrivals={todayArrivals}
              todayDepartures={todayDepartures}
              overdue={overdue}
              inHouse={inHouse}
              upcoming7={upcoming7}
              unitById={unitById}
              onToggleCheckIn={toggleCheckIn}
              onToggleCheckOut={toggleCheckOut}
              onNewBooking={() => setBookingModal({})}
            />
          )}
          {view === "units" && (
            <UnitsView
              units={units}
              bookings={bookings}
              onAdd={() => setUnitModal({})}
              onEdit={(u) => setUnitModal(u)}
              onDelete={(u) => setConfirmDelete({ type: "unit", id: u.id, label: u.name })}
            />
          )}
          {view === "calendar" && (
            <CalendarView
              units={units}
              bookings={bookings}
              unitById={unitById}
              month={calMonth}
              setMonth={setCalMonth}
            />
          )}
          {view === "bookings" && (
            <BookingsView
              bookings={sortedBookings}
              units={units}
              unitById={unitById}
              onAdd={() => setBookingModal({})}
              onEdit={(b) => setBookingModal(b)}
              onDelete={(b) =>
                setConfirmDelete({
                  type: "booking",
                  id: b.id,
                  label: `${b.guestName} — ${unitById[b.unitId]?.name || t("unit")}`,
                })
              }
              onToggleCheckIn={toggleCheckIn}
              onToggleCheckOut={toggleCheckOut}
            />
          )}
          {view === "contracts" && (
            <ContractsView
              bookings={sortedBookings}
              unitById={unitById}
              owner={owner}
              setOwner={persistOwner}
              contractBookingId={contractBookingId}
              setContractBookingId={setContractBookingId}
              contractText={contractText}
              setContractText={setContractText}
              onDownload={downloadContract}
              onOpen={openContract}
            />
          )}
          {view === "requests" && (
            <RequestsView requests={requests} unitById={unitById} bookings={bookings} onAccept={acceptRequest} onDecline={declineRequest} />
          )}
          {view === "website" && <WebsiteView site={site} setSite={persistSite} />}
        </main>
      </div>

      {unitModal !== null && (
        <UnitModal unit={unitModal} onClose={() => setUnitModal(null)} onSave={saveUnit} />
      )}
      {bookingModal !== null && (
        <BookingModal
          booking={bookingModal}
          units={units}
          unitById={unitById}
          onClose={() => setBookingModal(null)}
          onSave={saveBooking}
        />
      )}
      {confirmDelete && (
        <ConfirmModal
          label={confirmDelete.label}
          onCancel={() => setConfirmDelete(null)}
          onConfirm={() => {
            if (confirmDelete.type === "unit") deleteUnit(confirmDelete.id);
            else deleteBooking(confirmDelete.id);
          }}
        />
      )}
    </div>
  );
}

/* ---------------- Sidebar ---------------- */

function Sidebar({ view, setView, unitCount, lang, setLang, pending }) {
  const items = [
    { id: "dashboard", label: t("Overview"), icon: LayoutDashboard },
    { id: "units", label: t("Units"), icon: Building2 },
    { id: "calendar", label: t("Calendar"), icon: CalendarDays },
    { id: "bookings", label: t("Bookings"), icon: ClipboardList },
    { id: "contracts", label: t("Contracts"), icon: FileText },
    { id: "requests", label: t("Requests"), icon: Inbox, badge: pending },
    { id: "website", label: t("Website"), icon: Globe },
  ];
  return (
    <div
      style={{ background: COLORS.surface, borderRight: `1px solid ${COLORS.border}` }}
      className="md:w-56 w-full flex md:flex-col shrink-0"
    >
      <div className="px-5 py-5 hidden md:block">
        <div className="kf-serif text-xl" style={{ color: COLORS.ink }}>
          Keystone
        </div>
        <div className="text-xs mt-0.5" style={{ color: COLORS.inkSoft }}>
          {unitCount} {t(unitCount === 1 ? "unit managed" : "units managed")}
        </div>
      </div>
      <nav className="flex md:flex-col flex-1 md:px-3 md:pb-5 overflow-x-auto md:overflow-visible">
        {items.map((it) => {
          const Icon = it.icon;
          const active = view === it.id;
          return (
            <button
              key={it.id}
              onClick={() => setView(it.id)}
              className="flex items-center gap-2.5 px-4 md:px-3 py-3 text-sm shrink-0 md:w-full text-left transition-colors"
              style={{
                color: active ? COLORS.accent : COLORS.inkSoft,
                background: active ? COLORS.accentSoft : "transparent",
                borderRadius: 6,
                fontWeight: active ? 600 : 500,
              }}
            >
              <Icon size={16} strokeWidth={2} />
              {it.label}
              {it.badge ? (
                <span className="text-[10px] px-1.5 rounded-full" style={{ background: COLORS.amber, color: "#fff", fontWeight: 700 }}>
                  {it.badge}
                </span>
              ) : null}
            </button>
          );
        })}
      </nav>
      <div className="flex items-center gap-1 px-3 py-3 md:pb-5 shrink-0">
        {["en", "fr"].map((l) => (
          <button
            key={l}
            onClick={() => setLang(l)}
            className="text-xs px-2.5 py-1.5 rounded"
            style={{
              background: lang === l ? COLORS.accent : "transparent",
              color: lang === l ? "#fff" : COLORS.inkSoft,
              border: `1px solid ${COLORS.border}`,
              fontWeight: 600,
            }}
          >
            {l.toUpperCase()}
          </button>
        ))}
      </div>
    </div>
  );
}

/* ---------------- Dashboard ---------------- */

function Dashboard({
  units,
  todayArrivals,
  todayDepartures,
  overdue,
  inHouse,
  upcoming7,
  unitById,
  onToggleCheckIn,
  onToggleCheckOut,
  onNewBooking,
}) {
  return (
    <div>
      <PageHeader
        title={t("Overview")}
        subtitle={new Date().toLocaleDateString(LOC(), { weekday: "long", month: "long", day: "numeric" })}
        action={{ label: t("New booking"), onClick: onNewBooking }}
      />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-8">
        <StatCard label={t("Units")} value={units.length} />
        <StatCard label={t("In house")} value={inHouse.length} tone="accent" />
        <StatCard label={t("Arriving today")} value={todayArrivals.length} tone="amber" />
        <StatCard label={t("Departing today")} value={todayDepartures.length} tone="amber" />
      </div>

      {overdue.length > 0 && (
        <Section title={t("Needs attention")} icon={AlertTriangle} tone="red">
          {overdue.map((b) => (
            <BookingRow key={b.id} booking={b} unit={unitById[b.unitId]} onToggleCheckIn={onToggleCheckIn} onToggleCheckOut={onToggleCheckOut} />
          ))}
        </Section>
      )}

      {todayArrivals.length > 0 && (
        <Section title={t("Arriving today")}>
          {todayArrivals.map((b) => (
            <BookingRow key={b.id} booking={b} unit={unitById[b.unitId]} onToggleCheckIn={onToggleCheckIn} onToggleCheckOut={onToggleCheckOut} />
          ))}
        </Section>
      )}

      {todayDepartures.length > 0 && (
        <Section title={t("Departing today")}>
          {todayDepartures.map((b) => (
            <BookingRow key={b.id} booking={b} unit={unitById[b.unitId]} onToggleCheckIn={onToggleCheckIn} onToggleCheckOut={onToggleCheckOut} />
          ))}
        </Section>
      )}

      <Section title={t("Next 7 days")}>
        {upcoming7.length === 0 ? (
          <EmptyRow text={t("No arrivals in the next week.")} />
        ) : (
          upcoming7.map((b) => (
            <BookingRow key={b.id} booking={b} unit={unitById[b.unitId]} onToggleCheckIn={onToggleCheckIn} onToggleCheckOut={onToggleCheckOut} />
          ))
        )}
      </Section>
    </div>
  );
}

function StatCard({ label, value, tone }) {
  const color = tone === "accent" ? COLORS.accent : tone === "amber" ? COLORS.amber : COLORS.ink;
  return (
    <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.border}`, borderRadius: 8 }} className="p-4">
      <div className="kf-serif text-3xl" style={{ color }}>
        {value}
      </div>
      <div className="text-xs mt-1" style={{ color: COLORS.inkSoft }}>
        {label}
      </div>
    </div>
  );
}

function Section({ title, icon: Icon, tone, children }) {
  const color = tone === "red" ? COLORS.red : COLORS.ink;
  return (
    <div className="mb-7">
      <div className="flex items-center gap-1.5 mb-2.5">
        {Icon && <Icon size={14} style={{ color }} />}
        <h3 className="text-sm font-semibold" style={{ color }}>
          {title}
        </h3>
      </div>
      <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.border}`, borderRadius: 8 }}>
        {children}
      </div>
    </div>
  );
}

function EmptyRow({ text }) {
  return (
    <div className="px-4 py-5 text-sm" style={{ color: COLORS.inkSoft }}>
      {text}
    </div>
  );
}

function BookingRow({ booking, unit, onToggleCheckIn, onToggleCheckOut }) {
  const status = getBookingStatus(booking);
  const meta = STATUS_META[status];
  return (
    <div
      className="flex items-center justify-between gap-3 px-4 py-3"
      style={{ borderBottom: `1px solid ${COLORS.border}` }}
    >
      <div className="min-w-0">
        <div className="text-sm font-medium truncate">{booking.guestName || t("Unnamed guest")}</div>
        <div className="text-xs mt-0.5" style={{ color: COLORS.inkSoft }}>
          {unit?.name || t("Unknown unit")} · {fmtDate(booking.checkIn)}{booking.checkInTime ? ` ${fmtTime(booking.checkInTime)}` : ""} → {fmtDate(booking.checkOut)}{booking.checkOutTime ? ` ${fmtTime(booking.checkOutTime)}` : ""}
        </div>
      </div>
      <div className="flex items-center gap-2 shrink-0">
        <span
          className="text-xs px-2 py-1 rounded"
          style={{ color: meta.color, background: meta.bg, fontWeight: 600 }}
        >
          {t(meta.label)}
        </span>
        {!booking.checkedInAt && (
          <button
            onClick={() => onToggleCheckIn(booking)}
            className="text-xs px-2.5 py-1.5 rounded flex items-center gap-1"
            style={{ background: COLORS.accent, color: "#fff", fontWeight: 600 }}
          >
            <LogIn size={12} /> {t("Check in")}
          </button>
        )}
        {booking.checkedInAt && !booking.checkedOutAt && (
          <button
            onClick={() => onToggleCheckOut(booking)}
            className="text-xs px-2.5 py-1.5 rounded flex items-center gap-1"
            style={{ background: COLORS.ink, color: "#fff", fontWeight: 600 }}
          >
            <LogOut size={12} /> {t("Check out")}
          </button>
        )}
      </div>
    </div>
  );
}

function PageHeader({ title, subtitle, action }) {
  return (
    <div className="flex items-start justify-between mb-6 gap-3">
      <div>
        <h1 className="kf-serif text-2xl md:text-3xl" style={{ color: COLORS.ink }}>
          {title}
        </h1>
        {subtitle && (
          <p className="text-sm mt-1" style={{ color: COLORS.inkSoft }}>
            {subtitle}
          </p>
        )}
      </div>
      {action && (
        <button
          onClick={action.onClick}
          className="text-sm px-3.5 py-2 rounded flex items-center gap-1.5 shrink-0"
          style={{ background: COLORS.accent, color: "#fff", fontWeight: 600 }}
        >
          <Plus size={15} /> {action.label}
        </button>
      )}
    </div>
  );
}

/* ---------------- Units ---------------- */

function UnitsView({ units, bookings, onAdd, onEdit, onDelete }) {
  return (
    <div>
      <PageHeader title={t("Units")} subtitle={`${units.length} ${t(units.length === 1 ? "property" : "properties")}`} action={{ label: t("Add unit"), onClick: onAdd }} />
      {units.length === 0 ? (
        <EmptyState text={t("No units yet. Add your first apartment to get started.")} />
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {units.map((u) => {
            const active = bookings.find(
              (b) => b.unitId === u.id && getBookingStatus(b) === "in-house"
            );
            return (
              <div key={u.id} style={{ background: COLORS.surface, border: `1px solid ${COLORS.border}`, borderRadius: 8 }} className="p-4 flex flex-col">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="font-semibold text-sm truncate">{u.name}</div>
                    {u.address && (
                      <div className="text-xs mt-0.5" style={{ color: COLORS.inkSoft }}>
                        {u.address}
                      </div>
                    )}
                  </div>
                  <span
                    className="text-xs px-2 py-1 rounded shrink-0"
                    style={{
                      color: active ? COLORS.accent : COLORS.inkSoft,
                      background: active ? COLORS.accentSoft : "#EDECE6",
                      fontWeight: 600,
                    }}
                  >
                    {active ? t("Occupied") : t("Vacant")}
                  </span>
                </div>
                {(u.photos || []).length > 0 && (
                  <img src={u.photos[0]} alt="" className="w-full h-28 object-cover rounded mt-3" onError={(e) => { e.currentTarget.style.display = "none"; }} />
                )}
                <div className="mt-2.5"><UnitFacts u={u} /></div>
                {(u.nightlyPrice || u.weeklyPrice || u.monthlyPrice) && (
                  <div className="flex gap-4 mt-2.5">
                    {[["nightlyPrice", "per night"], ["weeklyPrice", "per week"], ["monthlyPrice", "per month"]].map(([k, per]) =>
                      numOrNull(u[k]) != null ? (
                        <div key={k}>
                          <div className="text-sm font-semibold kf-serif" style={{ color: COLORS.accent }}>{money(u[k])}</div>
                          <div className="text-[10px]" style={{ color: COLORS.inkSoft }}>{t(per)}</div>
                        </div>
                      ) : null
                    )}
                  </div>
                )}
                {(numOrNull(u.cleaningFee) || (u.seasons || []).length > 0) && (
                  <div className="text-[11px] mt-1.5" style={{ color: COLORS.inkSoft }}>
                    {numOrNull(u.cleaningFee) ? `${t("Cleaning fee")} ${money(u.cleaningFee)}` : ""}
                    {numOrNull(u.cleaningFee) && (u.seasons || []).length ? " · " : ""}
                    {(u.seasons || []).length ? `${u.seasons.length} ${t(u.seasons.length === 1 ? "seasonal price" : "seasonal prices")}` : ""}
                  </div>
                )}
                {u.notes && (
                  <p className="text-xs mt-2.5 flex items-start gap-1" style={{ color: COLORS.inkSoft }}>
                    <Lock size={11} className="mt-0.5 shrink-0" /> <span>{u.notes}</span>
                  </p>
                )}
                <div className="flex gap-2 mt-3.5 pt-3" style={{ borderTop: `1px solid ${COLORS.border}` }}>
                  <button onClick={() => onEdit(u)} className="text-xs flex items-center gap-1 px-2 py-1" style={{ color: COLORS.inkSoft }}>
                    <Pencil size={12} /> {t("Edit")}
                  </button>
                  <button onClick={() => onDelete(u)} className="text-xs flex items-center gap-1 px-2 py-1" style={{ color: COLORS.red }}>
                    <Trash2 size={12} /> {t("Delete")}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function EmptyState({ text }) {
  return (
    <div
      style={{ background: COLORS.surface, border: `1px dashed ${COLORS.border}`, borderRadius: 8, color: COLORS.inkSoft }}
      className="p-10 text-center text-sm"
    >
      {text}
    </div>
  );
}

/* ---------------- Calendar (timeline) ---------------- */

const UNIT_COLORS = [
  { bg: "#DCE7E6", fg: "#2F5C5C" },
  { bg: "#F3E3D2", fg: "#9A5F2E" },
  { bg: "#E1E3F5", fg: "#4A4E9E" },
  { bg: "#F5DEE3", fg: "#A5486A" },
  { bg: "#E7ECD7", fg: "#5F6E33" },
  { bg: "#EADCF0", fg: "#7A4F94" },
  { bg: "#DFE6EA", fg: "#3D5A6B" },
  { bg: "#F2E1D6", fg: "#A15C3B" },
];

function validDate(str) {
  return !!str && !isNaN(parseDate(str).getTime());
}

function CalendarView({ units, bookings, unitById, month, setMonth }) {
  const year = month.getFullYear();
  const mo = month.getMonth();
  const daysInMonth = new Date(year, mo + 1, 0).getDate();
  const startDow = new Date(year, mo, 1).getDay(); // 0 = Sunday
  const weeksCount = Math.ceil((startDow + daysInMonth) / 7);
  const weeks = Array.from({ length: weeksCount }, (_, w) =>
    Array.from({ length: 7 }, (_, d) => new Date(year, mo, 1 - startDow + w * 7 + d))
  );
  const todayKey = todayStr();
  const keyOf = (d) =>
    `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  const weekdayNames = Array.from({ length: 7 }, (_, i) =>
    new Date(2023, 0, 1 + i).toLocaleDateString(LOC(), { weekday: "short" })
  );

  const colorOf = {};
  units.forEach((u, i) => {
    colorOf[u.id] = UNIT_COLORS[i % UNIT_COLORS.length];
  });

  const usable = bookings.filter((b) => unitById[b.unitId] && validDate(b.checkIn) && validDate(b.checkOut));

  const HEADER_H = 30;
  const LANE_H = 24;

  function layoutWeek(week) {
    const ws = week[0];
    const we = week[6];
    const evs = usable
      .map((b) => {
        const ci = parseDate(b.checkIn);
        const co = parseDate(b.checkOut);
        const last = co < ci ? ci : co;
        if (last < ws || ci > we) return null;
        const cs = ci < ws ? ws : ci;
        const ce = last > we ? we : last;
        return {
          b,
          startCol: Math.round((cs - ws) / 86400000),
          endCol: Math.round((ce - ws) / 86400000),
          contFromPrev: ci < ws,
          contToNext: last > we,
        };
      })
      .filter(Boolean)
      .sort((x, y) => x.startCol - y.startCol || y.endCol - y.startCol - (x.endCol - x.startCol));
    const lanes = [];
    const placed = evs.map((ev) => {
      let lane = lanes.findIndex((end) => end < ev.startCol);
      if (lane === -1) {
        lane = lanes.length;
        lanes.push(ev.endCol);
      } else {
        lanes[lane] = ev.endCol;
      }
      return { ...ev, lane };
    });
    return { placed, laneCount: lanes.length };
  }

  function shiftMonth(delta) {
    setMonth(new Date(year, mo + delta, 1));
  }
  function goToday() {
    const d = new Date();
    setMonth(new Date(d.getFullYear(), d.getMonth(), 1));
  }

  return (
    <div>
      <PageHeader title={t("Calendar")} subtitle={t("Occupancy across all units")} />

      <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <div className="kf-serif text-xl" style={{ color: COLORS.ink }}>
            {month.toLocaleDateString(LOC(), { month: "long", year: "numeric" })}
          </div>
          <button onClick={goToday} className="text-xs px-2 py-1 rounded" style={{ border: `1px solid ${COLORS.border}`, color: COLORS.inkSoft }}>
            {t("Today")}
          </button>
        </div>
        <div className="flex gap-1">
          <button onClick={() => shiftMonth(-1)} style={{ border: `1px solid ${COLORS.border}` }} className="p-1.5 rounded">
            <ChevronLeft size={15} />
          </button>
          <button onClick={() => shiftMonth(1)} style={{ border: `1px solid ${COLORS.border}` }} className="p-1.5 rounded">
            <ChevronRight size={15} />
          </button>
        </div>
      </div>

      {units.length > 0 && (
        <div className="flex items-center gap-x-4 gap-y-1 flex-wrap mb-3">
          {units.map((u) => (
            <div key={u.id} className="flex items-center gap-1.5">
              <span style={{ width: 10, height: 10, borderRadius: 3, background: colorOf[u.id].fg, display: "inline-block" }} />
              <span className="text-xs" style={{ color: COLORS.inkSoft }}>
                {u.name}
              </span>
            </div>
          ))}
        </div>
      )}

      {units.length === 0 ? (
        <EmptyState text={t("Add a unit to see it on the calendar.")} />
      ) : (
        <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.border}`, borderRadius: 8, overflow: "hidden" }}>
          <div className="grid grid-cols-7" style={{ borderBottom: `1px solid ${COLORS.border}` }}>
            {weekdayNames.map((n, i) => (
              <div
                key={i}
                className="text-[11px] font-semibold text-center py-2 uppercase"
                style={{ color: COLORS.inkSoft, borderRight: i < 6 ? `1px solid ${COLORS.border}` : "none" }}
              >
                {n}
              </div>
            ))}
          </div>

          {weeks.map((week, wi) => {
            const { placed, laneCount } = layoutWeek(week);
            const rowH = Math.max(96, HEADER_H + laneCount * LANE_H + 8);
            return (
              <div key={wi} className="relative" style={{ height: rowH, borderTop: wi === 0 ? "none" : `1px solid ${COLORS.border}` }}>
                <div className="grid grid-cols-7 h-full">
                  {week.map((d, di) => {
                    const inMonth = d.getMonth() === mo;
                    const isToday = keyOf(d) === todayKey;
                    return (
                      <div
                        key={di}
                        style={{
                          borderRight: di < 6 ? `1px solid ${COLORS.border}` : "none",
                          background: inMonth ? "transparent" : "#FAF9F6",
                        }}
                        className="px-1.5 pt-1.5"
                      >
                        <span
                          className="text-xs inline-flex items-center justify-center"
                          style={{
                            width: 22,
                            height: 22,
                            borderRadius: 11,
                            background: isToday ? COLORS.red : "transparent",
                            color: isToday ? "#fff" : inMonth ? COLORS.ink : "#B5B2A6",
                            fontWeight: isToday ? 700 : 500,
                          }}
                        >
                          {d.getDate()}
                        </span>
                      </div>
                    );
                  })}
                </div>
                <div className="absolute inset-0" style={{ pointerEvents: "none" }}>
                  {placed.map((ev) => {
                    const b = ev.b;
                    const span = ev.endCol - ev.startCol + 1;
                    const c = colorOf[b.unitId] || UNIT_COLORS[0];
                    const unitName = unitById[b.unitId]?.name || "";
                    const label = b.guestName || t("Unnamed guest");
                    return (
                      <div
                        key={b.id + "-" + wi}
                        title={`${label} · ${unitName} · ${fmtDate(b.checkIn)}${b.checkInTime ? " " + fmtTime(b.checkInTime) : ""} – ${fmtDate(b.checkOut)}${b.checkOutTime ? " " + fmtTime(b.checkOutTime) : ""}`}
                        style={{
                          position: "absolute",
                          pointerEvents: "auto",
                          left: `calc(${(ev.startCol / 7) * 100}% + 3px)`,
                          width: `calc(${(span / 7) * 100}% - 6px)`,
                          top: HEADER_H + ev.lane * LANE_H,
                          height: LANE_H - 3,
                          background: c.bg,
                          borderLeft: `3px solid ${c.fg}`,
                          borderTopLeftRadius: ev.contFromPrev ? 0 : 5,
                          borderBottomLeftRadius: ev.contFromPrev ? 0 : 5,
                          borderTopRightRadius: ev.contToNext ? 0 : 5,
                          borderBottomRightRadius: ev.contToNext ? 0 : 5,
                        }}
                        className="px-1.5 flex items-center overflow-hidden"
                      >
                        <span className="text-[11px] truncate" style={{ color: c.fg, fontWeight: 600 }}>
                          {label}
                          {span >= 2 && unitName ? ` · ${unitName}` : ""}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ---------------- Bookings ---------------- */

function BookingsView({ bookings, units, unitById, onAdd, onEdit, onDelete, onToggleCheckIn, onToggleCheckOut }) {
  return (
    <div>
      <PageHeader title={t("Bookings")} subtitle={`${bookings.length} ${t("total")}`} action={{ label: t("New booking"), onClick: onAdd }} />
      {units.length === 0 ? (
        <EmptyState text={t("Add a unit first, then create a booking.")} />
      ) : bookings.length === 0 ? (
        <EmptyState text={t("No bookings yet.")} />
      ) : (
        <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.border}`, borderRadius: 8 }}>
          {bookings.map((b) => {
            const status = getBookingStatus(b);
            const meta = STATUS_META[status];
            return (
              <div key={b.id} className="flex items-center justify-between gap-3 px-4 py-3" style={{ borderBottom: `1px solid ${COLORS.border}` }}>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium truncate">{b.guestName || t("Unnamed guest")}</span>
                    <span className="text-xs px-1.5 py-0.5 rounded" style={{ color: meta.color, background: meta.bg, fontWeight: 600 }}>
                      {t(meta.label)}
                    </span>
                  </div>
                  <div className="text-xs mt-0.5" style={{ color: COLORS.inkSoft }}>
                    {unitById[b.unitId]?.name || t("Unknown unit")} · {fmtDate(b.checkIn)}{b.checkInTime ? ` ${fmtTime(b.checkInTime)}` : ""} → {fmtDate(b.checkOut)}{b.checkOutTime ? ` ${fmtTime(b.checkOutTime)}` : ""} · {nights(b.checkIn, b.checkOut)} {t("nights")}
                    {numOrNull(b.price) != null ? ` · ${money(b.price)}` : ""}
                  </div>
                </div>
                <div className="flex items-center gap-1.5 shrink-0">
                  {!b.checkedInAt && (
                    <button onClick={() => onToggleCheckIn(b)} title={t("Check in")} className="p-1.5 rounded" style={{ background: COLORS.accentSoft, color: COLORS.accent }}>
                      <LogIn size={14} />
                    </button>
                  )}
                  {b.checkedInAt && !b.checkedOutAt && (
                    <button onClick={() => onToggleCheckOut(b)} title={t("Check out")} className="p-1.5 rounded" style={{ background: "#EDECE6", color: COLORS.ink }}>
                      <LogOut size={14} />
                    </button>
                  )}
                  {b.checkedOutAt && (
                    <button onClick={() => onToggleCheckOut(b)} title={t("Undo check-out")} className="p-1.5 rounded" style={{ background: COLORS.greenSoft, color: COLORS.green }}>
                      <Check size={14} />
                    </button>
                  )}
                  <button onClick={() => onEdit(b)} title={t("Edit")} className="p-1.5 rounded" style={{ color: COLORS.inkSoft }}>
                    <Pencil size={14} />
                  </button>
                  <button onClick={() => onDelete(b)} title={t("Delete")} className="p-1.5 rounded" style={{ color: COLORS.red }}>
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ---------------- Contracts ---------------- */

function ContractsView({ bookings, unitById, owner, setOwner, contractBookingId, setContractBookingId, contractText, setContractText, onDownload, onOpen }) {
  return (
    <div>
      <PageHeader title={t("Contracts")} subtitle={t("Generate a rental agreement from a booking")} />

      <div className="grid md:grid-cols-3 gap-3 mb-3">
        <LabeledInput label={t("Manager / company name")} value={owner.name} onChange={(v) => setOwner({ ...owner, name: v })} />
        <LabeledInput label={t("Manager address")} value={owner.address} onChange={(v) => setOwner({ ...owner, address: v })} />
        <LabeledInput label={t("Manager phone / email")} value={owner.contact} onChange={(v) => setOwner({ ...owner, contact: v })} />
      </div>

      <div className="mb-4">
        <label className="text-xs font-medium mb-1 block" style={{ color: COLORS.inkSoft }}>
          {t("Booking")}
        </label>
        <select
          value={contractBookingId}
          onChange={(e) => setContractBookingId(e.target.value)}
          className="w-full text-sm px-3 py-2 rounded"
          style={{ border: `1px solid ${COLORS.border}`, background: COLORS.surface }}
        >
          <option value="">{t("Select a booking…")}</option>
          {bookings.map((b) => (
            <option key={b.id} value={b.id}>
              {b.guestName || t("Unnamed")} — {unitById[b.unitId]?.name || t("unit")} ({fmtDate(b.checkIn)} → {fmtDate(b.checkOut)})
            </option>
          ))}
        </select>
      </div>

      {contractBookingId && (
        <div>
          <textarea
            value={contractText}
            onChange={(e) => setContractText(e.target.value)}
            className="w-full text-sm p-4 rounded kf-sans"
            style={{ border: `1px solid ${COLORS.border}`, background: COLORS.surface, minHeight: 420, lineHeight: 1.6, resize: "vertical" }}
          />
          <div className="flex gap-2 mt-3">
            <button
              onClick={onDownload}
              className="text-sm px-3.5 py-2 rounded flex items-center gap-1.5"
              style={{ background: COLORS.accent, color: "#fff", fontWeight: 600 }}
            >
              <FileDown size={14} /> {t("Download PDF")}
            </button>
            <button
              onClick={onOpen}
              className="text-sm px-3.5 py-2 rounded flex items-center gap-1.5"
              style={{ border: `1px solid ${COLORS.border}`, color: COLORS.ink, fontWeight: 600 }}
            >
              <Printer size={14} /> {t("Open & print")}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function LabeledInput({ label, value, onChange, type = "text" }) {
  return (
    <div>
      <label className="text-xs font-medium mb-1 block" style={{ color: COLORS.inkSoft }}>
        {label}
      </label>
      <input
        type={type}
        value={value || ""}
        onChange={(e) => onChange(e.target.value)}
        className="w-full text-sm px-3 py-2 rounded"
        style={{ border: `1px solid ${COLORS.border}`, background: COLORS.surface }}
      />
    </div>
  );
}

/* ---------------- Modals ---------------- */

function ModalShell({ title, onClose, children, wide }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: "rgba(32,48,47,0.45)" }}>
      <div
        style={{ background: COLORS.surface, borderRadius: 10, maxWidth: wide === "xl" ? 760 : wide ? 560 : 440, width: "100%", maxHeight: "88vh", overflowY: "auto" }}
        className="kf-sans"
      >
        <div className="flex items-center justify-between px-5 py-4" style={{ borderBottom: `1px solid ${COLORS.border}` }}>
          <h3 className="font-semibold text-sm" style={{ color: COLORS.ink }}>
            {title}
          </h3>
          <button onClick={onClose} style={{ color: COLORS.inkSoft }}>
            <X size={18} />
          </button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
}

function SectionLabel({ children }) {
  return (
    <div className="text-[11px] font-semibold uppercase tracking-wide mt-6 mb-2.5 pb-1.5" style={{ color: COLORS.accent, borderBottom: `1px solid ${COLORS.border}` }}>
      {children}
    </div>
  );
}

function LabeledTextArea({ label, value, onChange, minHeight = 80 }) {
  return (
    <div>
      <label className="text-xs font-medium mb-1 block" style={{ color: COLORS.inkSoft }}>{label}</label>
      <textarea value={value || ""} onChange={(e) => onChange(e.target.value)} className="w-full text-sm px-3 py-2 rounded" style={{ border: `1px solid ${COLORS.border}`, minHeight }} />
    </div>
  );
}

function UnitModal({ unit, onClose, onSave }) {
  const u0 = normUnit(unit);
  const str = (v) => (v == null ? "" : String(v));
  const [f, setF] = useState({
    name: u0.name || "", address: u0.address || "", description: u0.description,
    bedrooms: str(u0.bedrooms), bathrooms: str(u0.bathrooms), maxGuests: str(u0.maxGuests),
    amenities: u0.amenities, photos: u0.photos.length ? u0.photos : [""],
    nightlyPrice: str(u0.nightlyPrice), weeklyPrice: str(u0.weeklyPrice), monthlyPrice: str(u0.monthlyPrice),
    cleaningFee: str(u0.cleaningFee), seasons: u0.seasons.map((x) => ({ yearly: true, ...x, id: x.id || uid() })), notes: u0.notes,
  });
  const set = (k) => (v) => setF((p) => ({ ...p, [k]: v }));
  const toggleAmenity = (id) =>
    setF((p) => ({ ...p, amenities: p.amenities.includes(id) ? p.amenities.filter((x) => x !== id) : [...p.amenities, id] }));
  const setPhoto = (i, v) => setF((p) => ({ ...p, photos: p.photos.map((x, j) => (j === i ? v : x)) }));
  const removePhoto = (i) => setF((p) => ({ ...p, photos: p.photos.length > 1 ? p.photos.filter((_, j) => j !== i) : [""] }));
  const makeCover = (i) => setF((p) => ({ ...p, photos: [p.photos[i], ...p.photos.filter((_, j) => j !== i)] }));
  const setSeason = (i, k, v) => setF((p) => ({ ...p, seasons: p.seasons.map((x, j) => (j === i ? { ...x, [k]: v } : x)) }));
  const addSeason = () => setF((p) => ({ ...p, seasons: [...p.seasons, { id: uid(), name: "", start: "", end: "", nightlyPrice: "", yearly: true }] }));
  const removeSeason = (i) => setF((p) => ({ ...p, seasons: p.seasons.filter((_, j) => j !== i) }));

  const seasonEmpty = (x) => !x.name.trim() && !x.start && !x.end && x.nightlyPrice === "";
  const seasonComplete = (x) => x.start && x.end && numOrNull(x.nightlyPrice) != null;
  const seasonsOk = f.seasons.every((x) => seasonEmpty(x) || seasonComplete(x));
  const valid = f.name.trim() && seasonsOk;
  const example = quoteStay({ ...f, seasons: f.seasons.filter(seasonComplete) }, todayStr(), addDaysStr(todayStr(), 7));

  function save() {
    const photos = f.photos.map((x) => x.trim()).filter(Boolean);
    onSave({
      ...unit,
      ...f,
      name: f.name.trim(),
      address: f.address.trim(),
      description: f.description.trim(),
      notes: f.notes.trim(),
      photos,
      photo: photos[0] || "",
      seasons: f.seasons.filter(seasonComplete).map((x) => ({ ...x, name: x.name.trim() })),
    });
  }

  const box = { border: `1px solid ${COLORS.border}`, borderRadius: 8 };

  return (
    <ModalShell title={unit.id ? t("Edit unit") : t("Add unit")} onClose={onClose} wide="xl">
      <SectionLabel>{t("Details")}</SectionLabel>
      <div className="grid sm:grid-cols-2 gap-3">
        <LabeledInput label={t("Unit name")} value={f.name} onChange={set("name")} />
        <LabeledInput label={t("Address")} value={f.address} onChange={set("address")} />
      </div>
      <div className="grid grid-cols-3 gap-3 mt-3">
        <LabeledInput label={t("Bedrooms")} type="number" value={f.bedrooms} onChange={set("bedrooms")} />
        <LabeledInput label={t("Bathrooms")} type="number" value={f.bathrooms} onChange={set("bathrooms")} />
        <LabeledInput label={t("Max guests")} type="number" value={f.maxGuests} onChange={set("maxGuests")} />
      </div>
      <div className="mt-3">
        <LabeledTextArea label={t("Description (shown on the website)")} value={f.description} onChange={set("description")} minHeight={90} />
      </div>

      <SectionLabel>{t("Amenities")}</SectionLabel>
      <div className="flex flex-wrap gap-1.5">
        {AMENITIES.map(([id, label]) => {
          const on = f.amenities.includes(id);
          return (
            <button
              key={id}
              type="button"
              onClick={() => toggleAmenity(id)}
              className="text-xs px-2.5 py-1.5 rounded-full flex items-center gap-1"
              style={{ border: `1px solid ${on ? COLORS.accent : COLORS.border}`, background: on ? COLORS.accentSoft : "transparent", color: on ? COLORS.accent : COLORS.inkSoft, fontWeight: 600 }}
            >
              {on && <Check size={11} />} {t(label)}
            </button>
          );
        })}
      </div>

      <SectionLabel>{t("Photos")}</SectionLabel>
      <p className="text-[11px] mb-2" style={{ color: COLORS.inkSoft }}>
        {t("Paste a link to an image (for example from Google Photos shared albums, Dropbox or your website). The first photo is the cover.")}
      </p>
      <div className="space-y-2">
        {f.photos.map((url, i) => (
          <div key={i} className="flex items-center gap-2">
            <div className="shrink-0 rounded overflow-hidden flex items-center justify-center" style={{ width: 52, height: 40, background: "#EDECE6" }}>
              {url.trim() ? <img src={url.trim()} alt="" className="w-full h-full object-cover" onError={(e) => { e.currentTarget.style.opacity = 0; }} /> : null}
            </div>
            <input
              aria-label={t("Photo URL")}
              placeholder={t("Photo URL")}
              value={url}
              onChange={(e) => setPhoto(i, e.target.value)}
              className="flex-1 min-w-0 text-sm px-3 py-2 rounded"
              style={{ border: `1px solid ${COLORS.border}` }}
            />
            {i === 0 ? (
              <span className="text-[10px] px-1.5 py-0.5 rounded shrink-0" style={{ background: COLORS.accentSoft, color: COLORS.accent, fontWeight: 700 }}>{t("Cover")}</span>
            ) : (
              <button type="button" onClick={() => makeCover(i)} className="text-[11px] shrink-0 underline" style={{ color: COLORS.inkSoft }}>{t("Make cover")}</button>
            )}
            <button type="button" title={t("Remove")} onClick={() => removePhoto(i)} className="p-1.5 shrink-0" style={{ color: COLORS.red }}>
              <Trash2 size={13} />
            </button>
          </div>
        ))}
      </div>
      <button type="button" onClick={() => setF((p) => ({ ...p, photos: [...p.photos, ""] }))} className="text-xs mt-2 flex items-center gap-1" style={{ color: COLORS.accent, fontWeight: 600 }}>
        <Plus size={13} /> {t("Add photo")}
      </button>

      <SectionLabel>{t("Pricing")}</SectionLabel>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <LabeledInput label={t("Nightly price")} type="number" value={f.nightlyPrice} onChange={set("nightlyPrice")} />
        <LabeledInput label={t("Weekly price")} type="number" value={f.weeklyPrice} onChange={set("weeklyPrice")} />
        <LabeledInput label={t("Monthly price")} type="number" value={f.monthlyPrice} onChange={set("monthlyPrice")} />
        <LabeledInput label={t("Cleaning fee")} type="number" value={f.cleaningFee} onChange={set("cleaningFee")} />
      </div>
      <p className="text-[11px] mt-2" style={{ color: COLORS.inkSoft }}>
        {t("Short stays use the nightly price. Stays of 7+ nights use the weekly price, 28+ nights the monthly price. Season nights always use the season price.")}
      </p>

      <SectionLabel>{t("Seasonal prices")}</SectionLabel>
      <div className="space-y-2.5">
        {f.seasons.map((x, i) => (
          <div key={x.id} className="p-3" style={box}>
            <div className="flex items-center gap-2">
              <input
                aria-label={t("Season name (e.g. Summer)")}
                placeholder={t("Season name (e.g. Summer)")}
                value={x.name}
                onChange={(e) => setSeason(i, "name", e.target.value)}
                className="flex-1 min-w-0 text-sm px-3 py-2 rounded"
                style={{ border: `1px solid ${COLORS.border}` }}
              />
              <button type="button" title={t("Remove")} onClick={() => removeSeason(i)} className="p-1.5" style={{ color: COLORS.red }}>
                <Trash2 size={13} />
              </button>
            </div>
            <div className="grid grid-cols-3 gap-2 mt-2">
              <LabeledInput label={t("From")} type="date" value={x.start} onChange={(v) => setSeason(i, "start", v)} />
              <LabeledInput label={t("To")} type="date" value={x.end} onChange={(v) => setSeason(i, "end", v)} />
              <LabeledInput label={t("Price per night")} type="number" value={x.nightlyPrice} onChange={(v) => setSeason(i, "nightlyPrice", v)} />
            </div>
            <label className="flex items-center gap-1.5 text-xs mt-2" style={{ color: COLORS.inkSoft }}>
              <input type="checkbox" checked={x.yearly !== false} onChange={(e) => setSeason(i, "yearly", e.target.checked)} />
              {t("Repeats every year")}
            </label>
          </div>
        ))}
      </div>
      <button type="button" onClick={addSeason} className="text-xs mt-2 flex items-center gap-1" style={{ color: COLORS.accent, fontWeight: 600 }}>
        <Plus size={13} /> {t("Add seasonal price")}
      </button>
      {!seasonsOk && <p className="text-xs mt-2" style={{ color: COLORS.red }}>{t("Complete or remove the unfinished seasonal price.")}</p>}

      <div className="mt-4 text-xs" style={{ color: COLORS.inkSoft }}>
        {example ? (
          <span>{t("Example: 7 nights from today would cost")} <strong style={{ color: COLORS.ink }}>{money(example.total)}</strong></span>
        ) : (
          t("Add a price to see an example.")
        )}
      </div>

      <SectionLabel>{t("Private")}</SectionLabel>
      <LabeledTextArea label={t("Private notes (only you see these)")} value={f.notes} onChange={set("notes")} minHeight={60} />

      <div className="flex justify-end gap-2 mt-5">
        <button onClick={onClose} className="text-sm px-3.5 py-2 rounded" style={{ color: COLORS.inkSoft }}>
          {t("Cancel")}
        </button>
        <button
          disabled={!valid}
          onClick={save}
          className="text-sm px-3.5 py-2 rounded"
          style={{ background: valid ? COLORS.accent : COLORS.border, color: "#fff", fontWeight: 600 }}
        >
          {t("Save unit")}
        </button>
      </div>
    </ModalShell>
  );
}

function BookingModal({ booking, units, unitById, onClose, onSave }) {
  const [unitId, setUnitId] = useState(booking.unitId || (units[0] && units[0].id) || "");
  const [guestName, setGuestName] = useState(booking.guestName || "");
  const [guestContact, setGuestContact] = useState(booking.guestContact || "");
  const [checkIn, setCheckIn] = useState(booking.checkIn || todayStr());
  const [checkInTime, setCheckInTime] = useState(booking.checkInTime || "15:00");
  const [checkOut, setCheckOut] = useState(booking.checkOut || todayStr());
  const [checkOutTime, setCheckOutTime] = useState(booking.checkOutTime || "11:00");
  const [price, setPrice] = useState(booking.price || "");
  const [priceTouched, setPriceTouched] = useState(!!booking.price);
  const [notes, setNotes] = useState(booking.notes || "");

  const valid = unitId && guestName.trim() && checkIn && checkOut && checkOut >= checkIn;
  const quote = quoteStay(unitById[unitId], checkIn, checkOut);
  const quoteTotal = quote ? quote.total : null;
  useEffect(() => {
    if (!priceTouched && quoteTotal != null) setPrice(String(quoteTotal));
  }, [quoteTotal, priceTouched]);

  return (
    <ModalShell title={booking.id ? t("Edit booking") : t("New booking")} onClose={onClose} wide>
      <div className="grid sm:grid-cols-2 gap-3">
        <div className="sm:col-span-2">
          <label className="text-xs font-medium mb-1 block" style={{ color: COLORS.inkSoft }}>
            {t("Unit")}
          </label>
          <select
            value={unitId}
            onChange={(e) => setUnitId(e.target.value)}
            className="w-full text-sm px-3 py-2 rounded"
            style={{ border: `1px solid ${COLORS.border}` }}
          >
            {units.map((u) => (
              <option key={u.id} value={u.id}>
                {u.name}
              </option>
            ))}
          </select>
        </div>
        <LabeledInput label={t("Guest name")} value={guestName} onChange={setGuestName} />
        <LabeledInput label={t("Guest phone / email")} value={guestContact} onChange={setGuestContact} />
        <LabeledInput label={t("Check-in date")} type="date" value={checkIn} onChange={setCheckIn} />
        <LabeledInput label={t("Check-in time")} type="time" value={checkInTime} onChange={setCheckInTime} />
        <LabeledInput label={t("Check-out date")} type="date" value={checkOut} onChange={setCheckOut} />
        <LabeledInput label={t("Check-out time")} type="time" value={checkOutTime} onChange={setCheckOutTime} />
        <LabeledInput label={t("Price (total)")} type="number" value={price} onChange={(v) => { setPrice(v); setPriceTouched(v !== ""); }} />
        <div className="sm:col-span-2">
          {quote ? (
            <QuoteBox
              quote={quote}
              title={t("Suggested price")}
              action={
                numOrNull(price) !== quote.total ? (
                  <button type="button" onClick={() => { setPrice(String(quote.total)); setPriceTouched(false); }} className="text-[11px] underline" style={{ color: COLORS.accent, fontWeight: 600 }}>
                    {t("Use this price")}
                  </button>
                ) : null
              }
            />
          ) : nights(checkIn, checkOut) > 0 ? (
            <p className="text-xs" style={{ color: COLORS.inkSoft }}>{t("No price set for this apartment yet.")}</p>
          ) : null}
        </div>
        <div className="sm:col-span-2">
          <label className="text-xs font-medium mb-1 block" style={{ color: COLORS.inkSoft }}>
            {t("Notes")}
          </label>
          <textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            className="w-full text-sm px-3 py-2 rounded"
            style={{ border: `1px solid ${COLORS.border}`, minHeight: 70 }}
          />
        </div>
      </div>
      {checkOut < checkIn && (
        <p className="text-xs mt-2" style={{ color: COLORS.red }}>
          {t("Check-out must be on or after check-in.")}
        </p>
      )}
      <div className="flex justify-end gap-2 mt-5">
        <button onClick={onClose} className="text-sm px-3.5 py-2 rounded" style={{ color: COLORS.inkSoft }}>
          {t("Cancel")}
        </button>
        <button
          disabled={!valid}
          onClick={() =>
            onSave({
              ...booking,
              unitId,
              guestName: guestName.trim(),
              guestContact: guestContact.trim(),
              checkIn,
              checkInTime,
              checkOut,
              checkOutTime,
              price,
              notes: notes.trim(),
            })
          }
          className="text-sm px-3.5 py-2 rounded"
          style={{ background: valid ? COLORS.accent : COLORS.border, color: "#fff", fontWeight: 600 }}
        >
          {t("Save booking")}
        </button>
      </div>
    </ModalShell>
  );
}

function ConfirmModal({ label, onCancel, onConfirm }) {
  return (
    <ModalShell title={t("Confirm delete")} onClose={onCancel}>
      <p className="text-sm" style={{ color: COLORS.inkSoft }}>
        {t("Delete")} <strong style={{ color: COLORS.ink }}>{label}</strong>{t("? This can't be undone.")}
      </p>
      <div className="flex justify-end gap-2 mt-5">
        <button onClick={onCancel} className="text-sm px-3.5 py-2 rounded" style={{ color: COLORS.inkSoft }}>
          {t("Cancel")}
        </button>
        <button onClick={onConfirm} className="text-sm px-3.5 py-2 rounded" style={{ background: COLORS.red, color: "#fff", fontWeight: 600 }}>
          {t("Delete")}
        </button>
      </div>
    </ModalShell>
  );
}


/* ---------------- Requests & Website settings (manager) ---------------- */

function RequestRow({ r, unit, conflict, onAccept, onDecline }) {
  const pending = r.status === "pending";
  return (
    <div className="px-4 py-3 flex items-start justify-between gap-3 flex-wrap" style={{ borderBottom: `1px solid ${COLORS.border}` }}>
      <div className="min-w-0">
        <div className="text-sm font-medium">{r.guestName} <span style={{ color: COLORS.inkSoft, fontWeight: 400 }}>· {r.guestContact}</span></div>
        <div className="text-xs mt-0.5" style={{ color: COLORS.inkSoft }}>
          {unit?.name || t("Unknown unit")} · {fmtDate(r.checkIn)} → {fmtDate(r.checkOut)} · {nights(r.checkIn, r.checkOut)} {t("nights")}
        </div>
        {r.message && <div className="text-xs mt-1.5" style={{ color: COLORS.ink }}>“{r.message}”</div>}
        {pending && conflict && (
          <div className="text-xs mt-1.5 flex items-center gap-1" style={{ color: COLORS.red }}>
            <AlertTriangle size={12} /> {t("Dates overlap an existing booking")}
          </div>
        )}
      </div>
      {pending ? (
        <div className="flex gap-2 shrink-0">
          <button onClick={() => onAccept(r)} className="text-xs px-3 py-1.5 rounded" style={{ background: COLORS.accent, color: "#fff", fontWeight: 600 }}>{t("Accept")}</button>
          <button onClick={() => onDecline(r)} className="text-xs px-3 py-1.5 rounded" style={{ border: `1px solid ${COLORS.border}`, color: COLORS.inkSoft, fontWeight: 600 }}>{t("Decline")}</button>
        </div>
      ) : (
        <span className="text-xs px-2 py-1 rounded shrink-0" style={{ background: r.status === "accepted" ? COLORS.greenSoft : "#EDECE6", color: r.status === "accepted" ? COLORS.green : COLORS.inkSoft, fontWeight: 600 }}>
          {t(r.status === "accepted" ? "Accepted" : "Declined")}
        </span>
      )}
    </div>
  );
}

function RequestsView({ requests, unitById, bookings, onAccept, onDecline }) {
  const sorted = [...requests].sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));
  const pending = sorted.filter((r) => r.status === "pending");
  const handled = sorted.filter((r) => r.status !== "pending");
  return (
    <div>
      <PageHeader title={t("Requests")} subtitle={t("Booking requests from your website")} />
      {requests.length === 0 ? (
        <EmptyState text={t("No requests yet. Requests from your website will appear here.")} />
      ) : (
        <>
          {pending.length > 0 && (
            <Section title={t("Pending")}>
              {pending.map((r) => (
                <RequestRow key={r.id} r={r} unit={unitById[r.unitId]} conflict={!isAvailable(r.unitId, r.checkIn, r.checkOut, bookings)} onAccept={onAccept} onDecline={onDecline} />
              ))}
            </Section>
          )}
          {handled.length > 0 && (
            <Section title={t("Handled")}>
              {handled.map((r) => (
                <RequestRow key={r.id} r={r} unit={unitById[r.unitId]} />
              ))}
            </Section>
          )}
        </>
      )}
    </div>
  );
}

function WebsiteView({ site, setSite }) {
  return (
    <div>
      <PageHeader title={t("Website")} subtitle={t("Branding and contact details shown to visitors")} />
      <div className="grid md:grid-cols-2 gap-3 mb-4">
        <LabeledInput label={t("Brand name")} value={site.brand} onChange={(v) => setSite({ ...site, brand: v })} />
        <LabeledInput label={t("Tagline")} value={site.tagline} onChange={(v) => setSite({ ...site, tagline: v })} />
        <LabeledInput label={t("City / area")} value={site.city} onChange={(v) => setSite({ ...site, city: v })} />
        <LabeledInput label={t("Contact email")} value={site.email} onChange={(v) => setSite({ ...site, email: v })} />
        <LabeledInput label={t("Contact phone")} value={site.phone} onChange={(v) => setSite({ ...site, phone: v })} />
        <div>
          <label className="text-xs font-medium mb-1 block" style={{ color: COLORS.inkSoft }}>{t("Currency")}</label>
          <select value={site.currency || "€"} onChange={(e) => setSite({ ...site, currency: e.target.value })} className="w-full text-sm px-3 py-2 rounded" style={{ border: `1px solid ${COLORS.border}`, background: COLORS.surface }}>
            {CURRENCIES.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
      </div>
      <a href="#/" className="text-sm px-3.5 py-2 rounded inline-flex items-center gap-1.5" style={{ background: COLORS.accent, color: "#fff", fontWeight: 600 }}>
        <ExternalLink size={14} /> {t("Open website")}
      </a>
      <p className="text-xs mt-4 max-w-xl" style={{ color: COLORS.inkSoft }}>
        {t("Your website lives at the address of this file followed by #/ and the owner area at #/admin. Booking requests sent from the website arrive in Requests.")}
      </p>
    </div>
  );
}

/* ---------------- Public landing page ---------------- */

const DEEP = "#1F3B3C";
const SAND = "#F4EFE4";

function RequestModal({ unit, bookings, defaultCi, defaultCo, onClose }) {
  const [name, setName] = useState("");
  const [contact, setContact] = useState("");
  const [a, setA] = useState(defaultCi);
  const [b, setB] = useState(defaultCo);
  const [message, setMessage] = useState("");
  const [err, setErr] = useState("");
  const [done, setDone] = useState(false);

  async function submit() {
    setErr("");
    if (!name.trim() || !contact.trim()) return setErr(t("Please enter your name and contact."));
    if (!a || !b || b <= a || a < todayStr()) return setErr(t("Please choose valid dates."));
    const fresh = await readKey(BOOKINGS_KEY, bookings);
    if (!isAvailable(unit.id, a, b, fresh)) return setErr(t("Sorry, those dates are no longer available."));
    if (window.keystoneDb) {
      try {
        await window.keystoneDb.submitRequest({ unitId: unit.id, guestName: name.trim(), guestContact: contact.trim(), checkIn: a, checkOut: b, message: message.trim() });
        return setDone(true);
      } catch (e) {
        const m = String((e && e.message) || "");
        if (m.includes("unavailable")) return setErr(t("Sorry, those dates are no longer available."));
        if (m.includes("invalid_dates")) return setErr(t("Please choose valid dates."));
        return setErr(t("Something went wrong. Please try again."));
      }
    }
    const reqs = await readKey(REQ_KEY, []);
    const r = { id: uid(), unitId: unit.id, guestName: name.trim(), guestContact: contact.trim(), checkIn: a, checkOut: b, message: message.trim(), createdAt: new Date().toISOString(), status: "pending" };
    try {
      await window.storage.set(REQ_KEY, JSON.stringify([...reqs, r]), false);
      setDone(true);
    } catch (e) {
      setErr(t("Something went wrong. Please try again."));
    }
  }

  return (
    <ModalShell title={`${t("Request to book")} — ${unit.name}`} onClose={onClose} wide>
      {done ? (
        <div>
          <p className="text-sm">{t("Request sent! We will get back to you shortly.")}</p>
          <div className="flex justify-end mt-5">
            <button onClick={onClose} className="text-sm px-3.5 py-2 rounded" style={{ background: COLORS.accent, color: "#fff", fontWeight: 600 }}>{t("Close")}</button>
          </div>
        </div>
      ) : (
        <div>
          <div className="grid sm:grid-cols-2 gap-3">
            <LabeledInput label={t("Arrival")} type="date" value={a} onChange={setA} />
            <LabeledInput label={t("Departure")} type="date" value={b} onChange={setB} />
            <LabeledInput label={t("Your name")} value={name} onChange={setName} />
            <LabeledInput label={t("Email or phone")} value={contact} onChange={setContact} />
            <div className="sm:col-span-2">
              <label className="text-xs font-medium mb-1 block" style={{ color: COLORS.inkSoft }}>{t("Message (optional)")}</label>
              <textarea value={message} onChange={(e) => setMessage(e.target.value)} className="w-full text-sm px-3 py-2 rounded" style={{ border: `1px solid ${COLORS.border}`, minHeight: 70 }} />
            </div>
          </div>
          {a && b && b > a && (
            quoteStay(unit, a, b) ? (
              <div className="mt-3"><QuoteBox quote={quoteStay(unit, a, b)} title={t("Estimated total")} /></div>
            ) : (
              <p className="text-xs mt-2" style={{ color: COLORS.inkSoft }}>{nights(a, b)} {t("nights")}</p>
            )
          )}
          {err && <p className="text-xs mt-2" style={{ color: COLORS.red }}>{err}</p>}
          <div className="flex justify-end gap-2 mt-5">
            <button onClick={onClose} className="text-sm px-3.5 py-2 rounded" style={{ color: COLORS.inkSoft }}>{t("Cancel")}</button>
            <button onClick={submit} className="text-sm px-3.5 py-2 rounded" style={{ background: COLORS.accent, color: "#fff", fontWeight: 600 }}>{t("Send request")}</button>
          </div>
        </div>
      )}
    </ModalShell>
  );
}

function PhotoStrip({ photos, name, color }) {
  const [i, setI] = useState(0);
  const [broken, setBroken] = useState({});
  const list = (photos || []).filter((p) => p && !broken[p]);
  if (!list.length) {
    return (
      <div className="h-48 flex items-center justify-center kf-serif" style={{ background: color.bg, color: color.fg, fontSize: 56 }}>
        {(name || "?").charAt(0).toUpperCase()}
      </div>
    );
  }
  const idx = i % list.length;
  const cur = list[idx];
  const arrow = { background: "rgba(255,255,255,0.88)", color: DEEP, borderRadius: 999, width: 28, height: 28 };
  return (
    <div className="relative h-48" style={{ background: "#E9E4D8" }}>
      <img src={cur} alt={name} className="w-full h-48 object-cover" onError={() => setBroken((b) => ({ ...b, [cur]: true }))} />
      {list.length > 1 && (
        <>
          <button aria-label={t("Previous photo")} onClick={() => setI((idx - 1 + list.length) % list.length)} className="absolute left-2 top-1/2 -translate-y-1/2 flex items-center justify-center" style={arrow}><ChevronLeft size={16} /></button>
          <button aria-label={t("Next photo")} onClick={() => setI((idx + 1) % list.length)} className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center justify-center" style={arrow}><ChevronRight size={16} /></button>
          <div className="absolute bottom-2 left-0 right-0 flex justify-center gap-1">
            {list.map((_, j) => (
              <span key={j} style={{ width: 6, height: 6, borderRadius: 3, background: j === idx ? "#fff" : "rgba(255,255,255,0.5)" }} />
            ))}
          </div>
        </>
      )}
    </div>
  );
}

export function Landing() {
  const [lang, setLangState] = useState("en");
  CURRENT_LANG = lang;
  const [data, setData] = useState({ units: [], bookings: [], site: DEFAULT_SITE });
  const [ci, setCi] = useState("");
  const [co, setCo] = useState("");
  const [pick, setPick] = useState(null);

  useEffect(() => {
    (async () => {
      const units = (await readKey(UNITS_KEY, [])).map(normUnit);
      const bookings = await readKey(BOOKINGS_KEY, []);
      const site = { ...DEFAULT_SITE, ...(await readKey(SITE_KEY, {})) };
      const l = await readKey(LANG_KEY, "en", true);
      setData({ units, bookings, site });
      if (l === "fr" || l === "en") setLangState(l);
    })();
  }, []);

  function changeLang(l) {
    setLangState(l);
    try { Promise.resolve(window.storage.set(LANG_KEY, l, false)).catch(() => {}); } catch (e) {}
  }

  const { units, bookings, site } = data;
  setCurrency(site.currency);
  const datesSet = ci && co && co > ci;
  const free = units.filter((u) => isAvailable(u.id, ci, co, bookings));
  const field = { border: `1px solid ${COLORS.border}`, background: "#fff", color: COLORS.ink };

  return (
    <div className="kf-sans" style={{ background: SAND, color: COLORS.ink, minHeight: "100vh" }}>
      <style>{FONT_STYLE}</style>

      <section style={{ background: DEEP, color: SAND }}>
        <div className="max-w-6xl mx-auto px-5 md:px-8">
          <div className="flex items-center justify-between py-5">
            <div className="kf-serif text-xl">{site.brand}</div>
            <div className="flex items-center gap-1">
              {["en", "fr"].map((l) => (
                <button key={l} onClick={() => changeLang(l)} className="text-xs px-2.5 py-1.5 rounded" style={{ background: lang === l ? SAND : "transparent", color: lang === l ? DEEP : SAND, border: `1px solid rgba(244,239,228,0.35)`, fontWeight: 600 }}>
                  {l.toUpperCase()}
                </button>
              ))}
            </div>
          </div>
          <div className="pt-12 pb-16 md:pt-20 md:pb-24 max-w-3xl">
            <h1 className="kf-serif text-4xl md:text-6xl" style={{ lineHeight: 1.08 }}>{site.tagline}</h1>
            {site.city && <p className="mt-4 text-base" style={{ opacity: 0.75 }}>{site.city}</p>}
          </div>
          <div className="pb-10">
            <div className="rounded-lg p-4 grid sm:grid-cols-3 gap-3 items-end" style={{ background: SAND }}>
              <div>
                <label className="text-xs font-medium mb-1 block" style={{ color: COLORS.inkSoft }}>{t("Arrival")}</label>
                <input type="date" min={todayStr()} value={ci} onChange={(e) => setCi(e.target.value)} className="w-full text-sm px-3 py-2 rounded" style={field} />
              </div>
              <div>
                <label className="text-xs font-medium mb-1 block" style={{ color: COLORS.inkSoft }}>{t("Departure")}</label>
                <input type="date" min={ci || todayStr()} value={co} onChange={(e) => setCo(e.target.value)} className="w-full text-sm px-3 py-2 rounded" style={field} />
              </div>
              <div className="text-sm" style={{ color: COLORS.ink }}>
                {datesSet ? (
                  <span>
                    <strong>{free.length}</strong> {t(free.length === 1 ? "apartment available" : "apartments available")}{" "}
                    <button onClick={() => { setCi(""); setCo(""); }} className="underline text-xs" style={{ color: COLORS.inkSoft }}>{t("Clear dates")}</button>
                  </span>
                ) : (
                  <span style={{ color: COLORS.inkSoft }}>{t("Find your stay")}</span>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-5 md:px-8 py-14">
        <h2 className="kf-serif text-3xl mb-7">{t("Our apartments")}</h2>
        {units.length === 0 ? (
          <p className="text-sm" style={{ color: COLORS.inkSoft }}>{t("No apartments are listed yet.")}</p>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {units.map((u, i) => {
              const ok = isAvailable(u.id, ci, co, bookings);
              const c = UNIT_COLORS[i % UNIT_COLORS.length];
              return (
                <div key={u.id} className="rounded-lg overflow-hidden flex flex-col" style={{ background: "#fff", border: `1px solid ${COLORS.border}`, opacity: ok ? 1 : 0.55 }}>
                  <PhotoStrip photos={u.photos} name={u.name} color={c} />
                  <div className="p-4 flex flex-col flex-1">
                    <div className="kf-serif text-xl">{u.name}</div>
                    {u.address && <div className="text-xs mt-0.5" style={{ color: COLORS.inkSoft }}>{u.address}</div>}
                    <div className="mt-2"><UnitFacts u={u} size={12} /></div>
                    {u.description && <p className="text-sm mt-2" style={{ color: COLORS.inkSoft, whiteSpace: "pre-line" }}>{u.description}</p>}
                    {u.amenities.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-2.5">
                        {u.amenities.slice(0, 6).map((a) => (
                          <span key={a} className="text-[11px] px-2 py-0.5 rounded-full" style={{ background: SAND, color: COLORS.ink }}>{t(AMENITY_LABEL[a] || a)}</span>
                        ))}
                        {u.amenities.length > 6 && (
                          <span className="text-[11px] px-2 py-0.5" style={{ color: COLORS.inkSoft }}>+{u.amenities.length - 6} {t("more")}</span>
                        )}
                      </div>
                    )}
                    <div className="flex flex-wrap gap-x-5 gap-y-2 mt-3">
                      {numOrNull(u.nightlyPrice) != null && (<div><div className="kf-serif text-lg" style={{ color: COLORS.accent }}>{money(u.nightlyPrice)}</div><div className="text-[11px]" style={{ color: COLORS.inkSoft }}>{t("per night")}</div></div>)}
                      {numOrNull(u.weeklyPrice) != null && (<div><div className="kf-serif text-lg" style={{ color: COLORS.accent }}>{money(u.weeklyPrice)}</div><div className="text-[11px]" style={{ color: COLORS.inkSoft }}>{t("per week")}</div></div>)}
                      {numOrNull(u.monthlyPrice) != null && (<div><div className="kf-serif text-lg" style={{ color: COLORS.accent }}>{money(u.monthlyPrice)}</div><div className="text-[11px]" style={{ color: COLORS.inkSoft }}>{t("per month")}</div></div>)}
                    </div>
                    {ok && datesSet && quoteStay(u, ci, co) && (
                      <div className="text-sm mt-2.5" style={{ color: COLORS.ink }}>
                        {nights(ci, co)} {t(nights(ci, co) === 1 ? "night" : "nights")} · <strong>{money(quoteStay(u, ci, co).total)}</strong> {t("total")}
                      </div>
                    )}
                    <div className="mt-auto pt-4">
                      {ok ? (
                        <button onClick={() => setPick(u)} className="w-full text-sm px-3.5 py-2.5 rounded" style={{ background: DEEP, color: SAND, fontWeight: 600 }}>{t("Request to book")}</button>
                      ) : (
                        <div className="text-xs text-center py-2.5" style={{ color: COLORS.red, fontWeight: 600 }}>{t("Not available for these dates")}</div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      <section className="max-w-6xl mx-auto px-5 md:px-8 pb-16">
        <h2 className="kf-serif text-3xl mb-7">{t("How it works")}</h2>
        <div className="grid md:grid-cols-3 gap-8">
          {[
            ["Pick your dates", "Choose an apartment and the dates that suit you."],
            ["Send a request", "Tell us who you are. No payment needed yet."],
            ["Get a confirmation", "We confirm availability and send your rental agreement."],
          ].map(([h, p], i) => (
            <div key={i}>
              <div className="kf-serif text-4xl" style={{ color: COLORS.amber }}>{i + 1}</div>
              <div className="font-semibold mt-1">{t(h)}</div>
              <p className="text-sm mt-1" style={{ color: COLORS.inkSoft }}>{t(p)}</p>
            </div>
          ))}
        </div>
      </section>

      <footer style={{ background: DEEP, color: SAND }}>
        <div className="max-w-6xl mx-auto px-5 md:px-8 py-10 flex flex-wrap justify-between gap-6">
          <div>
            <div className="kf-serif text-xl">{site.brand}</div>
            {site.city && <div className="text-sm mt-1" style={{ opacity: 0.75 }}>{site.city}</div>}
          </div>
          <div className="text-sm">
            <div className="font-semibold mb-1">{t("Contact")}</div>
            {site.email && <div><a href={`mailto:${site.email}`}>{site.email}</a></div>}
            {site.phone && <div><a href={`tel:${site.phone}`}>{site.phone}</a></div>}
          </div>
          <a href="#/admin" className="text-xs self-end" style={{ opacity: 0.6 }}>{t("Owner area")}</a>
        </div>
      </footer>

      {pick && <RequestModal unit={pick} bookings={bookings} defaultCi={ci} defaultCo={co} onClose={() => setPick(null)} />}
    </div>
  );
}


/* ---------------- Owner sign-in (online mode only) ---------------- */

export function AdminGate({ children }) {
  const db = typeof window !== "undefined" ? window.keystoneDb : null;
  const [session, setSession] = useState(undefined);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [saveErr, setSaveErr] = useState(false);
  const [owner, setOwnerOk] = useState(undefined);
  let lang = "en";
  try { lang = localStorage.getItem(LANG_KEY) === "fr" ? "fr" : "en"; } catch (e) {}
  CURRENT_LANG = lang;

  useEffect(() => {
    if (!db) return;
    db.getSession().then((s) => setSession(s || null)).catch(() => setSession(null));
    const off = db.onAuth((s) => setSession(s || null));
    const onErr = () => setSaveErr(true);
    window.addEventListener("keystone-error", onErr);
    return () => { off(); window.removeEventListener("keystone-error", onErr); };
  }, []); // eslint-disable-line

  useEffect(() => {
    if (!db || !session) { setOwnerOk(undefined); return; }
    db.isOwner().then((v) => setOwnerOk(v)).catch(() => setOwnerOk(false));
  }, [session && session.user && session.user.id]); // eslint-disable-line

  if (!db) return children;

  if (session === undefined) {
    return (
      <div style={{ background: COLORS.bg, minHeight: "100vh" }} className="kf-sans flex items-center justify-center">
        <style>{FONT_STYLE}</style>
        <p style={{ color: COLORS.inkSoft }}>{t("Loading…")}</p>
      </div>
    );
  }

  if (!session) {
    async function submit(e) {
      e.preventDefault();
      setErr("");
      setBusy(true);
      try {
        await db.signIn(email.trim(), password);
      } catch (x) {
        setErr(t("Wrong email or password."));
      }
      setBusy(false);
    }
    return (
      <div style={{ background: COLORS.bg, minHeight: "100vh" }} className="kf-sans flex items-center justify-center p-5">
        <style>{FONT_STYLE}</style>
        <form onSubmit={submit} style={{ background: COLORS.surface, border: `1px solid ${COLORS.border}`, borderRadius: 10, width: "100%", maxWidth: 360 }} className="p-6">
          <div className="kf-serif text-2xl mb-1" style={{ color: COLORS.ink }}>Keystone</div>
          <div className="text-sm mb-5" style={{ color: COLORS.inkSoft }}>{t("Owner sign-in")}</div>
          <div className="space-y-3">
            <LabeledInput label={t("Email")} type="email" value={email} onChange={setEmail} />
            <LabeledInput label={t("Password")} type="password" value={password} onChange={setPassword} />
          </div>
          {err && <p className="text-xs mt-3" style={{ color: COLORS.red }}>{err}</p>}
          <button type="submit" disabled={busy} className="w-full text-sm px-3.5 py-2.5 rounded mt-5" style={{ background: COLORS.accent, color: "#fff", fontWeight: 600, opacity: busy ? 0.6 : 1 }}>
            {t("Sign in")}
          </button>
          <a href="#/" className="block text-center text-xs mt-4" style={{ color: COLORS.inkSoft }}>{t("Back to website")}</a>
        </form>
      </div>
    );
  }

  if (owner === undefined) {
    return (
      <div style={{ background: COLORS.bg, minHeight: "100vh" }} className="kf-sans flex items-center justify-center">
        <style>{FONT_STYLE}</style>
        <p style={{ color: COLORS.inkSoft }}>{t("Loading…")}</p>
      </div>
    );
  }

  if (owner === false) {
    return (
      <div style={{ background: COLORS.bg, minHeight: "100vh" }} className="kf-sans flex items-center justify-center p-5">
        <style>{FONT_STYLE}</style>
        <div style={{ background: COLORS.surface, border: `1px solid ${COLORS.border}`, borderRadius: 10, maxWidth: 380 }} className="p-6">
          <div className="kf-serif text-xl mb-2" style={{ color: COLORS.ink }}>Keystone</div>
          <p className="text-sm" style={{ color: COLORS.inkSoft }}>{t("This account is not on the owner list. Add its e-mail to the owners table in Supabase (see SETUP), then sign in again.")}</p>
          <button onClick={() => db.signOut()} className="text-sm px-3.5 py-2 rounded mt-5" style={{ background: COLORS.accent, color: "#fff", fontWeight: 600 }}>{t("Sign out")}</button>
        </div>
      </div>
    );
  }

  return (
    <div className="relative">
      {saveErr && (
        <div className="kf-sans text-sm px-4 py-2.5 flex items-center gap-2" style={{ background: COLORS.redSoft, color: COLORS.red, fontWeight: 600 }}>
          <AlertTriangle size={14} /> {t("Could not save to the database. Check your connection, then reload the page.")}
        </div>
      )}
      <button onClick={() => db.signOut()} className="kf-sans fixed bottom-4 right-4 z-40 text-xs px-3 py-2 rounded flex items-center gap-1.5" style={{ background: COLORS.surface, border: `1px solid ${COLORS.border}`, color: COLORS.inkSoft, fontWeight: 600 }}>
        <LogOut size={12} /> {t("Sign out")}
      </button>
      {children}
    </div>
  );
}
