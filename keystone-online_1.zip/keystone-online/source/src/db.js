// Supabase-backed version of the small storage API the app uses
// (window.storage.get / set). The app code stays the same: this layer
// maps its JSON objects to database rows and saves only what changed.

const num = (v) => (v === "" || v == null || isNaN(Number(v)) ? null : Number(v));
const int = (v) => { const n = num(v); return n == null ? null : Math.round(n); };
const arr = (v) => (Array.isArray(v) ? v : []);

// Columns visitors are allowed to read (everything except private notes).
const PUBLIC_UNIT_COLUMNS = "id,name,address,description,bedrooms,bathrooms,max_guests,amenities,photos,photo,nightly_price,weekly_price,monthly_price,cleaning_fee,seasons,created_at";
const str = (v) => (v == null ? "" : String(v));
const LANG_KEY = "keystone:lang";

const TABLES = {
  "keystone:units": {
    table: "units", order: "created_at",
    toDb: (u) => {
      const photos = arr(u.photos).filter(Boolean);
      return {
        id: u.id, name: u.name || "", address: u.address || "", description: u.description || "", notes: u.notes || "",
        bedrooms: int(u.bedrooms), bathrooms: int(u.bathrooms), max_guests: int(u.maxGuests),
        amenities: arr(u.amenities), photos, photo: photos[0] || u.photo || "",
        nightly_price: num(u.nightlyPrice), weekly_price: num(u.weeklyPrice), monthly_price: num(u.monthlyPrice),
        cleaning_fee: num(u.cleaningFee),
        seasons: arr(u.seasons).map((x) => ({ id: x.id, name: x.name || "", start: x.start, end: x.end, nightlyPrice: str(x.nightlyPrice), yearly: x.yearly !== false })),
      };
    },
    fromDb: (r) => ({
      id: r.id, name: r.name, address: r.address || "", description: r.description || "", notes: r.notes || "",
      bedrooms: str(r.bedrooms), bathrooms: str(r.bathrooms), maxGuests: str(r.max_guests),
      amenities: arr(r.amenities), photos: arr(r.photos).length ? arr(r.photos) : r.photo ? [r.photo] : [],
      nightlyPrice: str(r.nightly_price), weeklyPrice: str(r.weekly_price), monthlyPrice: str(r.monthly_price),
      cleaningFee: str(r.cleaning_fee), seasons: arr(r.seasons),
    }),
  },
  "keystone:bookings": {
    table: "bookings", order: "check_in",
    toDb: (b) => ({ id: b.id, unit_id: b.unitId, guest_name: b.guestName || "", guest_contact: b.guestContact || "", check_in: b.checkIn, check_in_time: b.checkInTime || "15:00", check_out: b.checkOut, check_out_time: b.checkOutTime || "11:00", price: num(b.price), notes: b.notes || "", checked_in_at: b.checkedInAt || null, checked_out_at: b.checkedOutAt || null }),
    fromDb: (r) => ({ id: r.id, unitId: r.unit_id, guestName: r.guest_name || "", guestContact: r.guest_contact || "", checkIn: r.check_in, checkInTime: r.check_in_time || "", checkOut: r.check_out, checkOutTime: r.check_out_time || "", price: str(r.price), notes: r.notes || "", checkedInAt: r.checked_in_at || null, checkedOutAt: r.checked_out_at || null }),
  },
  "keystone:requests": {
    table: "requests", order: "created_at",
    toDb: (r) => ({ id: r.id, unit_id: r.unitId, guest_name: r.guestName, guest_contact: r.guestContact, check_in: r.checkIn, check_out: r.checkOut, message: r.message || "", status: r.status || "pending" }),
    fromDb: (r) => ({ id: r.id, unitId: r.unit_id, guestName: r.guest_name, guestContact: r.guest_contact, checkIn: r.check_in, checkOut: r.check_out, message: r.message || "", status: r.status, createdAt: r.created_at }),
  },
};

const SINGLES = {
  "keystone:site": { table: "site_settings", cols: ["brand", "tagline", "city", "email", "phone", "currency"], publicRead: true },
  "keystone:owner-info": { table: "owner_info", cols: ["name", "address", "contact"], publicRead: false },
};

export function createDb(sb) {
  const cache = {};
  const emit = (msg) => {
    try { window.dispatchEvent(new CustomEvent("keystone-error", { detail: msg })); } catch (e) {}
  };
  const getSession = async () => (await sb.auth.getSession()).data.session;
  const signedIn = async () => !!(await getSession());

  async function loadRows(key) {
    const m = TABLES[key];
    let rows;
    if (key === "keystone:bookings" && !(await signedIn())) {
      // Visitors only ever receive dates, never guest details.
      const { data, error } = await sb.rpc("get_availability");
      if (error) throw error;
      rows = (data || []).map((r, i) => ({ id: "avail-" + i, unitId: r.unit_id, checkIn: r.check_in, checkOut: r.check_out }));
    } else if (key === "keystone:requests" && !(await signedIn())) {
      rows = [];
    } else {
      const cols = key === "keystone:units" && !(await signedIn()) ? PUBLIC_UNIT_COLUMNS : "*";
      const { data, error } = await sb.from(m.table).select(cols).order(m.order, { ascending: true });
      if (error) throw error;
      rows = (data || []).map(m.fromDb);
    }
    cache[key] = rows;
    return rows;
  }

  const storage = {
    async get(key) {
      if (key === LANG_KEY) {
        let v = null;
        try { v = localStorage.getItem(key); } catch (e) {}
        if (v == null) throw new Error("Key not found");
        return { key, value: v, shared: false };
      }
      if (TABLES[key]) return { key, value: JSON.stringify(await loadRows(key)), shared: false };
      const s = SINGLES[key];
      if (s) {
        if (!s.publicRead && !(await signedIn())) return { key, value: "{}", shared: false };
        const { data, error } = await sb.from(s.table).select("*").eq("id", 1).maybeSingle();
        if (error) throw error;
        const obj = {};
        s.cols.forEach((c) => { if (data && data[c] != null) obj[c] = data[c]; });
        return { key, value: JSON.stringify(obj), shared: false };
      }
      throw new Error("Key not found");
    },

    async set(key, value) {
      try {
        if (key === LANG_KEY) {
          try { localStorage.setItem(key, value); } catch (e) {}
          return { key, value, shared: false };
        }
        const next = JSON.parse(value);
        if (TABLES[key]) {
          const m = TABLES[key];
          const prev = cache[key] || (await loadRows(key));
          const prevById = new Map(prev.map((r) => [r.id, JSON.stringify(m.toDb(r))]));
          const nextIds = new Set(next.map((r) => r.id));
          const upserts = next.map(m.toDb).filter((row) => prevById.get(row.id) !== JSON.stringify(row));
          const removed = prev.filter((r) => !nextIds.has(r.id)).map((r) => r.id);
          if (upserts.length) {
            const { error } = await sb.from(m.table).upsert(upserts);
            if (error) throw error;
          }
          if (removed.length) {
            const { error } = await sb.from(m.table).delete().in("id", removed);
            if (error) throw error;
          }
          cache[key] = next;
        } else if (SINGLES[key]) {
          const s = SINGLES[key];
          const row = { id: 1 };
          s.cols.forEach((c) => { row[c] = next[c] == null ? "" : String(next[c]); });
          const { error } = await sb.from(s.table).upsert(row);
          if (error) throw error;
        }
        return { key, value, shared: false };
      } catch (e) {
        emit((e && e.message) || "save failed");
        throw e;
      }
    },
  };

  return {
    storage,
    getSession,
    onAuth(cb) {
      const { data } = sb.auth.onAuthStateChange((_evt, session) => {
        Object.keys(cache).forEach((k) => delete cache[k]);
        cb(session);
      });
      return () => data.subscription.unsubscribe();
    },
    async signIn(email, password) {
      const { error } = await sb.auth.signInWithPassword({ email, password });
      if (error) throw error;
    },
    signOut: () => sb.auth.signOut(),
    async isOwner() {
      const { data, error } = await sb.rpc("is_owner");
      if (error) throw error;
      return data === true;
    },
    async submitRequest(r) {
      const { error } = await sb.rpc("submit_request", {
        p_unit_id: r.unitId, p_name: r.guestName, p_contact: r.guestContact,
        p_check_in: r.checkIn, p_check_out: r.checkOut, p_message: r.message || "",
      });
      if (error) throw error;
    },
  };
}
