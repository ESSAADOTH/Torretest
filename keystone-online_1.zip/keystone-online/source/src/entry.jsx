import React, { useState, useEffect } from "react";
import { createRoot } from "react-dom/client";
import { createClient } from "@supabase/supabase-js";
import App, { Landing, AdminGate } from "./app.jsx";
import { createDb } from "./db.js";

const cfg = window.KEYSTONE_CONFIG || {};
const url = cfg.supabaseUrl || "";
const key = cfg.supabaseKey || cfg.supabaseAnonKey || "";
const online = !!url && !!key && !/YOUR-/i.test(url + key);

if (online) {
  const db = createDb(createClient(url, key));
  window.keystoneDb = db;
  window.storage = db.storage;
} else {
  // Local mode: no database configured, data stays in this browser only.
  const mem = {};
  const store = {
    get: (k) => { try { return localStorage.getItem(k); } catch (e) { return mem[k] ?? null; } },
    set: (k, v) => { try { localStorage.setItem(k, v); } catch (e) { mem[k] = v; } },
  };
  window.storage = {
    async get(k) {
      const v = store.get(k);
      if (v === null || v === undefined) throw new Error("Key not found");
      return { key: k, value: v, shared: false };
    },
    async set(k, v) { store.set(k, v); return { key: k, value: v, shared: false }; },
  };
}

function Root() {
  const [h, setH] = useState(window.location.hash);
  useEffect(() => {
    const f = () => {
      setH(window.location.hash);
      try { window.scrollTo(0, 0); } catch (e) {}
    };
    window.addEventListener("hashchange", f);
    return () => window.removeEventListener("hashchange", f);
  }, []);
  return h.startsWith("#/admin") ? (
    <AdminGate><App key="admin" /></AdminGate>
  ) : (
    <Landing key="site" />
  );
}

createRoot(document.getElementById("root")).render(<Root />);
