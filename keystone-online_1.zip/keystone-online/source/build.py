"""Build Keystone into:
  dist/online/index.html + config.js   (website + manager, uses Supabase when config.js is filled in)
  dist/keystone-rental-manager.html    (single offline file, data stays in the browser)
Usage: python3 build.py [--alias-supabase path/to/fake.js]
"""
import subprocess, sys, os, pathlib

root = pathlib.Path(__file__).parent
dist = root / "dist"
(dist / "online").mkdir(parents=True, exist_ok=True)

alias = []
out_js = dist / "bundle.js"
if "--alias-supabase" in sys.argv:
    alias = ["--alias:@supabase/supabase-js=" + sys.argv[sys.argv.index("--alias-supabase") + 1]]
    out_js = dist / "bundle-test.js"

subprocess.run(["npx", "tailwindcss", "-c", "tailwind.config.js", "-i", "src/in.css", "-o", str(dist / "out.css"), "--minify"],
               cwd=root, check=True, capture_output=True)
subprocess.run(["npx", "esbuild", "src/entry.jsx", "--bundle", "--minify", "--loader:.jsx=jsx",
                "--define:process.env.NODE_ENV=\"production\"", "--outfile=" + str(out_js),
                # jsPDF's optional HTML/SVG renderers are never used by Keystone
                "--external:html2canvas", "--external:canvg", "--external:dompurify"] + alias,
               cwd=root, check=True)

js = out_js.read_text(encoding="utf-8").replace("</script", "<\\/script")
css = (dist / "out.css").read_text(encoding="utf-8")

def page(config_tag):
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Keystone</title>
{config_tag}
<style>{css}
html,body,#root{{margin:0;min-height:100%;background:#F6F5F0}}</style>
</head>
<body>
<div id="root"></div>
<script>{js}</script>
</body>
</html>"""

if alias:
    (dist / "test.html").write_text(page(""), encoding="utf-8")
else:
    (dist / "online" / "index.html").write_text(page('<script src="config.js"></script>'), encoding="utf-8")
    (dist / "keystone-rental-manager.html").write_text(page(""), encoding="utf-8")
print("built", out_js.name, os.path.getsize(out_js) // 1024, "KB")
